//
//  UserWorkModel.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserWorkModel : NSObject

@property (nonatomic,copy) NSString *avatar_medium;
@property (nonatomic,copy) NSString *diaries_count;
@property (nonatomic,copy) NSString *email;
@property (nonatomic,copy) NSString *favorites_count;
@property (nonatomic,copy) NSString *followers_count;
@property (nonatomic,copy) NSString *following_count;
@property (nonatomic,copy) NSString *location;
@property (nonatomic,copy) NSString *sign;
@property (nonatomic,copy) NSString *user_cover;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *user_large_photo;
@property (nonatomic,copy) NSString *user_photo;
@property (nonatomic,copy) NSString *weibo_nick;
@property (nonatomic,copy) NSString *nick;
@property (nonatomic,copy) NSString *recipes_count;
@end
