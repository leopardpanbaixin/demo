//
//  UserWorkModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "UserWorkModel.h"

@implementation UserWorkModel

- (void)dealloc
{
    [_avatar_medium release];
    [_diaries_count release];
    [_email release];
    [_favorites_count release];
    [_followers_count release];
    [_following_count release];
    [_location release];
    [_sign release];
    [_user_cover release];
    [_user_id release];
    [_user_large_photo release];
    [_user_photo release];
    [_weibo_nick release];
    [_nick release];
    [_recipes_count release];
    [super dealloc];
    
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"未成功赋值的key%@",key);
}

@end
