//
//  ActivityModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-30.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ActivityModel.h"

@implementation ActivityModel

- (void)dealloc
{
    [_end_date release];
    [_name release];
    [_type release];
    [_image release];
    [_ActivityId release];
    [_copy release];
    [_url release];
    [super dealloc];
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"未成功赋值的key%@",key);
}
@end
