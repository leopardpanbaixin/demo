//
//  WorkModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "WorkModel.h"

@implementation WorkModel

- (void)dealloc
{
    [_cook_title release];
    [_description release];
    [_dish_id release];
    [_image release];
    [_cook_id release];
    [_comments_count release];
    [_likes_count release];
    [_publishtime release];
    [_ts release];
    [_like_users release];
    [super dealloc];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"未成功赋值的key%@",key);
}
@end
