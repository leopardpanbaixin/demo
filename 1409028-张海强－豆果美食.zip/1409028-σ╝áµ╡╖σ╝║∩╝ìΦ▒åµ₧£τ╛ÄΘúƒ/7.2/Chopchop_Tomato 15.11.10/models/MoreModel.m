//
//  MoreModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "MoreModel.h"

@implementation MoreModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
      NSLog(@"%s",__FUNCTION__);
    NSLog(@"%@",key);
}

@end
