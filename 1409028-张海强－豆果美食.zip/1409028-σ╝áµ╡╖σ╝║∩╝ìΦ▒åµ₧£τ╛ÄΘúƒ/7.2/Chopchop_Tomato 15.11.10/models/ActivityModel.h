//
//  ActivityModel.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-30.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ActivityModel : NSObject

@property (nonatomic,copy) NSString *end_date;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *type;
@property (nonatomic,copy) NSString *image;
@property (nonatomic,copy) NSString *ActivityId;
@property (nonatomic,copy) NSString *copy;
@property (nonatomic,copy) NSString *url;
@end
