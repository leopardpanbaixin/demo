//
//  TopicHeaderModel.m
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-7-6.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "TopicHeaderModel.h"

@implementation TopicHeaderModel

- (void)dealloc
{
    [_d release];
    [_i release];
    [_topId release];
    [_t release];
    [_tc release];
    [_uc release];
    [super dealloc];
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"%@",key);
}
@end
