//
//  LikeModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "LikeModel.h"

@implementation LikeModel

- (void)dealloc
{
    [_images release];
    [_text release];
    [super dealloc];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
      NSLog(@"%s",__FUNCTION__);
    NSLog(@"%@",key);
}
@end
