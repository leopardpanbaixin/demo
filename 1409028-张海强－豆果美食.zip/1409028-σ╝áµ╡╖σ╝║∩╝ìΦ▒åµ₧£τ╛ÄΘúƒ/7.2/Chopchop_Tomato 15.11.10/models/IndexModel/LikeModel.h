//
//  LikeModel.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LikeModel : NSObject

@property (nonatomic,retain) NSArray *images;
@property (nonatomic,copy) NSString *text;

@end
