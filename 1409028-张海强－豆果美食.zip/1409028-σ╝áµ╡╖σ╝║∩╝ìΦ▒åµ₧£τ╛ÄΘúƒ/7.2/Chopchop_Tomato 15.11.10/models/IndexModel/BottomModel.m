//
//  BottomModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "BottomModel.h"

@implementation BottomModel

- (void)dealloc
{
    [_content release];
    [_description release];
    [_display_name release];
    [_image_url release];
    [_type release];
    [super dealloc];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"%s---%@",__FUNCTION__,key);
}
@end
