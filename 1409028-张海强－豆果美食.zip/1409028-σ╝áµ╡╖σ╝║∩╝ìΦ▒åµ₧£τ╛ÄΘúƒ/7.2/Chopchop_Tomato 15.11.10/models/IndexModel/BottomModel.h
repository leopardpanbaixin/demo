//
//  BottomModel.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BottomModel : NSObject

@property (nonatomic,retain) NSDictionary *content;
@property (nonatomic,copy) NSString *description;
@property (nonatomic,copy) NSString *display_name;
@property (nonatomic,copy) NSString *image_url;
@property (nonatomic,copy) NSString *type;

@end
