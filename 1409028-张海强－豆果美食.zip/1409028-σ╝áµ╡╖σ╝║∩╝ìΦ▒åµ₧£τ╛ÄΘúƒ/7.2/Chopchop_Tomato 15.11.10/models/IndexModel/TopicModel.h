//
//  TopicModel.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TopicModel : NSObject

@property (nonatomic,copy) NSString *d;
@property (nonatomic,copy) NSString *i;
@property (nonatomic,retain) NSArray *is;
@property (nonatomic,copy) NSString *t;
@property (nonatomic,copy) NSString *tc;
@property (nonatomic,retain) NSNumber *uc;

@end
