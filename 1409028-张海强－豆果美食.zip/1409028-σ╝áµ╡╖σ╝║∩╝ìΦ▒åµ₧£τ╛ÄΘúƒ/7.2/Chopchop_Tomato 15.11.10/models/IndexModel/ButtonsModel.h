//
//  ButtonsModel.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ButtonsModel : NSObject

@property (nonatomic,copy) NSString *background;
@property (nonatomic,copy) NSString *image_url;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,retain) NSNumber *points;

@end
