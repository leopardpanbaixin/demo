//
//  ScrollModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ScrollModel.h"

@implementation ScrollModel

- (void)dealloc
{
    [_image_url release];
    [super dealloc];
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"%@",key);
}
@end
