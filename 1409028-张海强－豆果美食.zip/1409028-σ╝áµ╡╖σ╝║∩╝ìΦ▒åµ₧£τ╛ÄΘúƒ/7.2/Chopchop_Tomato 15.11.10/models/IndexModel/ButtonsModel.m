//
//  ButtonsModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ButtonsModel.h"

@implementation ButtonsModel

- (void)dealloc
{
    [_background release];
    [_image_url release];
    [_name release];
    [_points release];
    [super dealloc];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"%s",__FUNCTION__);
    NSLog(@"%@",key);
}
@end
