//
//  TopicHeaderModel.h
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-7-6.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TopicHeaderModel : NSObject

@property (nonatomic,copy) NSString *d;
@property (nonatomic,copy) NSString *i;
@property (nonatomic,copy) NSString *topId;
@property (nonatomic,copy) NSString *t;
@property (nonatomic,copy) NSString *tc;
@property (nonatomic,copy) NSString *uc;

@end
