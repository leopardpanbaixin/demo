//
//  DetailModel.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DetailModel : NSObject

@property (nonatomic,copy) NSString *op;
@property (nonatomic,copy) NSString *p;
@property (nonatomic,copy) NSString *rr;
@property (nonatomic,copy) NSString *rt;
@property (nonatomic,retain) NSNumber *sc;
@property (nonatomic,retain) NSNumber *st;
@property (nonatomic,retain) NSNumber *state;
@property (nonatomic,copy) NSString *t;
@property (nonatomic,copy) NSString *thb;
@property (nonatomic,copy) NSString *wu;
@property (nonatomic,copy) NSString *et;

@end
