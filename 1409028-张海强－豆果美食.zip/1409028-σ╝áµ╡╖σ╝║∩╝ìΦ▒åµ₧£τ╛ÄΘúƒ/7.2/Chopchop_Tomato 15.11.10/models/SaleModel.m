//
//  SaleModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "SaleModel.h"

@implementation SaleModel

- (void)dealloc
{
    [_content release];
    [_description release];
    [_display_name release];
    [_image_url release];
    [_type release];
    [super dealloc];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"%@",key);
}
@end
