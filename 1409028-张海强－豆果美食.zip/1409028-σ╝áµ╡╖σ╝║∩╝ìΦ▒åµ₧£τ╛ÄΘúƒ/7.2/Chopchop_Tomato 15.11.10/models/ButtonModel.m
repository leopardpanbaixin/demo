//
//  ButtonModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ButtonModel.h"

@implementation ButtonModel

-(void)dealloc
{
    [_cook_id release];
    [_title release];
    [_image release];
    [_thumb_path release];
    [_photo_path release];
    [_thumb_height release];
    [_author_photo release];
    [_tags release];
    [_author release];
    [_author_id release];
    [_cookstory release];
    [_cookstep release];
    [_tips release];
    [super dealloc];
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"%s",__FUNCTION__);
    NSLog(@"没有赋值 %@",key);
  
}

@end
