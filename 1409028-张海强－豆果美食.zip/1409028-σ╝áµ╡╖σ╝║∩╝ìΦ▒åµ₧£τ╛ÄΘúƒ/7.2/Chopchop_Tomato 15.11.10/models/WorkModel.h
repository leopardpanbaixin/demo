//
//  WorkModel.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WorkModel : NSObject

@property (nonatomic,copy) NSString *cook_title;
@property (nonatomic,copy) NSString *description;
@property (nonatomic,copy) NSString *dish_id;
@property (nonatomic,copy) NSString *image;
@property (nonatomic,copy) NSString *cook_id;
@property (nonatomic,retain) NSNumber *comments_count;
@property (nonatomic,retain) NSNumber *likes_count;
@property (nonatomic,copy) NSString *publishtime;
@property (nonatomic,retain) NSArray *ts;
@property (nonatomic,retain) NSArray *like_users;
@end
