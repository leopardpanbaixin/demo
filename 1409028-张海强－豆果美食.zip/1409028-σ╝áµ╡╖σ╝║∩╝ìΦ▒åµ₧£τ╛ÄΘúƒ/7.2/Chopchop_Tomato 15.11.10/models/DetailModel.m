//
//  DetailModel.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "DetailModel.h"

@implementation DetailModel

- (void)dealloc
{
    [_op release];
    [_p release];
    [_rr release];
    [_rt release];
    [_sc release];
    [_st release];
    [_state release];
    [_t release];
    [_thb release];
    [_wu release];
    [_et release];
    [super dealloc];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
      NSLog(@"%s",__FUNCTION__);
    NSLog(@"%@",key);
}
@end
