//
//  ButtonModel.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ButtonModel : NSObject

@property(nonatomic,copy)NSString *cook_id;
@property(nonatomic,copy)NSString *title;
@property(nonatomic,copy)NSString *image;
@property(nonatomic,copy)NSString *thumb_path;
@property(nonatomic,copy)NSString *photo_path;
@property(nonatomic,copy)NSString *thumb_height;
@property(nonatomic,copy)NSString *author_photo;
@property(nonatomic,copy)NSString *tags;
@property(nonatomic,copy)NSString *author;
@property(nonatomic,copy)NSString *author_id;
@property(nonatomic,copy)NSString *cookstory;
@property(nonatomic,retain)NSArray *cookstep;
@property(nonatomic,copy)NSString *cook_time;
@property(nonatomic,copy)NSString *cook_difficulty;
@property(nonatomic,copy)NSString *clicks;
@property(nonatomic,retain)NSArray *major;

@property(nonatomic,retain)NSArray *minor;
@property(nonatomic,copy)NSString *collect_status;
@property(nonatomic,copy)NSString *create_time;
@property(nonatomic,retain)NSNumber *favo_counts;
@property(nonatomic,copy)NSString *comments_count;
@property(nonatomic,retain)NSNumber *dish_count;
@property(nonatomic,copy)NSString *recommended;
@property(nonatomic,copy)NSString *author_verified;
@property(nonatomic,copy)NSString *v_u;
@property (nonatomic,copy) NSString *tips;

@end
