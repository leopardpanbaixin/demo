//
//  HttpPostRequest.h
//  PostDemo
//
//  Created by Dove on 14-5-29.
//  Copyright (c) 2014年 Dove. All rights reserved.
//

#import <Foundation/Foundation.h>

//asi中，进行post请求和文件上传用ASIFormDataRequest
#import "ASIFormDataRequest.h"

@class HttpPostRequest;
@protocol HttpRequestDelegate <NSObject>

//数据请求成功
- (void) httpRequestFinished:(HttpPostRequest *)request;
//数据请求失败
- (void) httpRequestFailed:(HttpPostRequest *)request;

@end

@interface HttpPostRequest : NSObject <NSURLConnectionDataDelegate,ASIHTTPRequestDelegate>

@property (nonatomic,assign) id<HttpRequestDelegate>delegate;

//接收服务端的数据
@property (nonatomic,retain) NSMutableData *downloadData;

//进行post请求数据的方法
//函数参数含义：urlString，请求地址；method，请求方式（get/post）；type,请求参数的组织方式或者编码方式；dic，请求参数字典
- (void) downloadDataWithUrlString:(NSString *)urlString requestMethod:(NSString *)method contentType:(NSString *)type paraDic:(NSDictionary *)dic;

//使用asi进行post请求,需要请求地址，请求方式，参数
- (void) asiDownloadWithUrlString:(NSString *)urlStr requestMethod:(NSString *)method paraDic:(NSDictionary *)dic;

@end
