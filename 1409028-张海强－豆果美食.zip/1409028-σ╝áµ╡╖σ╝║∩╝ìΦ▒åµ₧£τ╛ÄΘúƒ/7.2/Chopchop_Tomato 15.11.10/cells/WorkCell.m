//
//  WorkCell.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "WorkCell.h"

@implementation WorkCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self makeUI];
    }
    return self;
}

- (void)makeUI
{
    UIImageView *backgroundImageView = [MyControl createImageViewFrame:CGRectMake(0, 0, ScreenWidth, 240) imageName:nil];
    backgroundImageView.backgroundColor = [UIColor whiteColor];
    [self.contentView addSubview:backgroundImageView];
    _cookImageView = [MyControl createImageViewFrame:CGRectMake(0, 0, ScreenWidth, 180) imageName:nil];
    [self.contentView addSubview:_cookImageView];
    _userImageView = [MyControl createImageViewFrame:CGRectMake(10, _cookImageView.bottom-60, 40, 40) imageName:@"default_avatar.png"];
    _userImageView.layer.cornerRadius = 20;
    _userImageView.layer.masksToBounds = YES;
    [self.contentView addSubview:_userImageView];
    UIControl *control = [[UIControl alloc] initWithFrame:CGRectMake(10, _cookImageView.bottom-60, 40, 40)];
    control.tag = 2013;
    [self.contentView addSubview:control];
    _cookTitleLabel = [MyControl createLabelWithFrame:CGRectMake(_userImageView.right+5, _userImageView.top-5, 100, 25) Font:16 Text:nil];
    _cookTitleLabel.textColor = [UIColor whiteColor];
    [self.contentView addSubview:_cookTitleLabel];
    _nameLabel = [MyControl createLabelWithFrame:CGRectMake(_userImageView.right+5, _cookTitleLabel.bottom+2, 140, 20) Font:12 Text:nil];
    _nameLabel.textColor = [UIColor whiteColor];
    [self.contentView addSubview:_nameLabel];
    _descriptionLabel = [MyControl createLabelWithFrame:CGRectMake(20, _cookImageView.bottom, 320, 0) Font:16 Text:nil];
    [self.contentView addSubview:_descriptionLabel];
    
    for (int i = 0; i<3; i++) {
        UIImageView *view = [MyControl createImageViewFrame:CGRectMake(30+(i%3)*100, _descriptionLabel.bottom+30, 20, 20) imageName:nil];
        [self.contentView addSubview:view];
        UILabel *label = [MyControl createLabelWithFrame:CGRectMake(view.right+(i%3)*2, _descriptionLabel.bottom+30, 30, 20) Font:14 Text:nil];
        label.tag = 2000+i;
        [self.contentView addSubview:label];
        UIControl *control = [[UIControl alloc] initWithFrame:CGRectMake((i%3)*110, _descriptionLabel.bottom+30, 100, 30)];
        control.tag = 2014+i;
        [self.contentView addSubview:control];
        if (i==0) {
            view.image = [UIImage imageNamed:@"detailed_dish_cell_share.png"];
            label.text = @"分享";
        }
        if (i==1) {
            view.image = [UIImage imageNamed:@"comments_recipe.png"];
        }
        if (i==2) {
            view.image = [UIImage imageNamed:@"detailed_dish_cell_like_normal.png"];
        }
    }
}
- (void)configModel:(WorkModel *)model
{
    
    [_cookImageView setImageWithURL:[NSURL URLWithString:model.image]];
    if (model.description) {
        _descriptionLabel.frame = CGRectMake(20, _cookImageView.bottom, 200, 30);
        _descriptionLabel.text = model.description;
    } else {
        _descriptionLabel.frame = CGRectMake(20, _cookImageView.bottom, 200, 0);
    }
    UILabel *label = (UILabel *)[self.contentView viewWithTag:2001];
    if ([model.comments_count intValue]>0) {
        label.text = [model.comments_count stringValue];
    } else {
        label.text = @"评论";
    }
   UILabel *label1 = (UILabel *)[self.contentView viewWithTag:2002];
    if ([model.likes_count intValue]>0) {
        label1.text = [model.likes_count stringValue];
    } else {
        label1.text = @"喜欢";
    }
    _cookTitleLabel.text = model.cook_title;
    _cookTitleLabel.font = [UIFont boldSystemFontOfSize:18];
}

- (void)configUserModel:(UserWorkModel *)model
{
    
    
    if (model.user_photo) {
         [_userImageView setImageWithURL:[NSURL URLWithString:model.user_photo]];
    } else {
        _userImageView.image = [UIImage imageNamed:@"default_avatar.png"];
    }
   
    _nameLabel.text = [NSString stringWithFormat:@"by %@",model.nick];
    _nameLabel.font = [UIFont boldSystemFontOfSize:14];
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
