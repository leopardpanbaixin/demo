//
//  StepCell.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-4.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "StepCell.h"

@implementation StepCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_detailLabel release];
    [_stepImageView release];
    [super dealloc];
}
@end
