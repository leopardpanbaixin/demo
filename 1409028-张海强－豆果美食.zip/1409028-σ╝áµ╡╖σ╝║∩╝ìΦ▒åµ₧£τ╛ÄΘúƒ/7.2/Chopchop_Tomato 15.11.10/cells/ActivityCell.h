//
//  ActivityCell.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-30.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActivityCell : UITableViewCell

@property (retain, nonatomic) IBOutlet UILabel *ActivityLabel;
@property (retain, nonatomic) IBOutlet UILabel *nameLabel;
@property (retain, nonatomic) IBOutlet UIImageView *activityImageView;
@property (retain, nonatomic) IBOutlet UILabel *timeLabel;
@end
