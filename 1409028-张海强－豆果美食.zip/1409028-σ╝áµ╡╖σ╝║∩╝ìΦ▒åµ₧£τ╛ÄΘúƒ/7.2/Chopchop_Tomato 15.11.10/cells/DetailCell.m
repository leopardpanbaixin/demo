//
//  DetailCell.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "DetailCell.h"

@implementation DetailCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_timeLabel release];
    [_saleImageView release];
    [_titleLabel release];
    [_detLabel release];
    [_curLabel release];
    [_oldLabel release];
    [_disLabel release];
    [_perLabel release];
    [super dealloc];
}
@end
