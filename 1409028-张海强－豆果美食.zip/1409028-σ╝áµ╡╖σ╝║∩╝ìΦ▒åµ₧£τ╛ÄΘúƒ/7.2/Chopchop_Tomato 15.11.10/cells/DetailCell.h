//
//  DetailCell.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *timeLabel;
@property (retain, nonatomic) IBOutlet UIImageView *saleImageView;
@property (retain, nonatomic) IBOutlet UILabel *titleLabel;

@property (retain, nonatomic) IBOutlet UILabel *detLabel;
@property (retain, nonatomic) IBOutlet UILabel *curLabel;
@property (retain, nonatomic) IBOutlet UILabel *oldLabel;
@property (retain, nonatomic) IBOutlet UILabel *disLabel;
@property (retain, nonatomic) IBOutlet UILabel *perLabel;
@end
