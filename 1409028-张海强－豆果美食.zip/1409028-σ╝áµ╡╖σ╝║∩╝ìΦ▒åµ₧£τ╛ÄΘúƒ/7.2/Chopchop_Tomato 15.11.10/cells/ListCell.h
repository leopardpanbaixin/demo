//
//  ListCell.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-26.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListCell : UITableViewCell

@end
