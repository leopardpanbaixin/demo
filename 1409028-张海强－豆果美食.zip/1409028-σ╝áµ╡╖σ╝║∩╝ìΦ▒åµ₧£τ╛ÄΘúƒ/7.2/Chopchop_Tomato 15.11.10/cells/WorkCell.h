//
//  WorkCell.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserWorkModel.h"
#import "WorkModel.h"
#import "UIImageView+WebCache.h"
#import "UIButton+WebCache.h"

@interface WorkCell : UITableViewCell {
    UILabel *_nameLabel;
    UILabel *_cookTitleLabel;
    UIImageView *_userImageView;
    UIImageView *_cookImageView;
    UILabel *_descriptionLabel;
}

- (void)configModel:(WorkModel *)model;
- (void)configUserModel:(UserWorkModel *)model;

@end
