//
//  ListCell.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-26.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ListCell.h"

@implementation ListCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
