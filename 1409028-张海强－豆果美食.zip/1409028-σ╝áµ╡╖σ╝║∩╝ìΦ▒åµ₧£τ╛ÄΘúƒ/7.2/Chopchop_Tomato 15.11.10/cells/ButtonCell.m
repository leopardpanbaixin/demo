//
//  ButtonCell.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ButtonCell.h"
#import "UIImageView+WebCache.h"
@implementation ButtonCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self makeUI];
    }
    return self;
}
-(void)makeUI
{
    imageView=[MyControl createImageViewFrame:CGRectMake(5, 5, 100, 70) imageName:nil];
    [self.contentView addSubview:imageView];
    
    nameLabel=[MyControl createLabelWithFrame:CGRectMake(120, 5, 200, 25) Font:14 Text:nil];
    [self.contentView addSubview:nameLabel];
    
    cailiaoLabel=[MyControl createLabelWithFrame:CGRectMake(120, 30, 200, 25) Font:12 Text:nil];
    [self.contentView addSubview:cailiaoLabel];
    
    favo_countsLabel=[MyControl createLabelWithFrame:CGRectMake(120, 55, 200, 20) Font:12 Text:nil]
    ;
    [self.contentView addSubview:favo_countsLabel];
}
-(void)config:(ButtonModel *)model
{
    [imageView setImageWithURL:[NSURL URLWithString:model.image] placeholderImage:[UIImage imageNamed:@""]];
    nameLabel.text=model.title;
    
    NSMutableString *str1=[[model.major firstObject]objectForKey:@"title"];
    for (NSDictionary *dic in model.minor) {
        NSString *string=[NSString stringWithString:[dic objectForKey:@"title"]];
        [str1 stringByAppendingFormat:@" %@",string];
    }
    cailiaoLabel.text=str1;
    
    favo_countsLabel.text=[NSString stringWithFormat:@"%@ 收藏  %@作品",model.favo_counts,model.dish_count];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
