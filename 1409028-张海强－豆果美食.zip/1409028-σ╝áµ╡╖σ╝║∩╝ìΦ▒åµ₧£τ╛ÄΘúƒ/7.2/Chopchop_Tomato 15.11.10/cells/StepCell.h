//
//  StepCell.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-4.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StepCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *detailLabel;
@property (retain, nonatomic) IBOutlet UIImageView *stepImageView;

@end
