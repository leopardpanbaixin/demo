//
//  ButtonCell.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ButtonModel.h"
@interface ButtonCell : UITableViewCell
{
    UIImageView *imageView;
    UILabel *nameLabel;
    UILabel *cailiaoLabel;
    UILabel *favo_countsLabel;//收藏
//    UILabel *dish_countLabel;//作品数
}
-(void)config:(ButtonModel *)model;
@end
