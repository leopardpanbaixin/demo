//
//  AppDelegate.m
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "AppDelegate.h"
#import "MainViewController.h"
#import "RootViewController.h"
#import "UMSocial.h"
#import "APService.h"


@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    
    //判断是否第一次运行
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *firstRunning = [defaults objectForKey:@"FirstRunning"];
    //不是第一次运行
    if ([firstRunning isEqualToString:@"1"]) {
        RootViewController *root = [[RootViewController alloc]init];
        UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:root];
        self.window.rootViewController = nc;
        [root release];
        [nc release];
    }
    else { //第一次运行
        [defaults setObject:@"1" forKey:@"FirstRunning"];
        [defaults synchronize];
        MainViewController * mainCtrl = [[MainViewController alloc] init];
        self.window.rootViewController = mainCtrl;
        [mainCtrl release];
    }
//    友盟初始化
    [UMSocialData setAppKey:@"53ae1ed356240b4569096"];
    
//    [ShareSDK registerApp:@"iosv1101" useAppTrusteeship:YES];
    
    //Jpush初始化
    [APService setupWithOption:launchOptions];
    //启动Jpush的类型
    [APService registerForRemoteNotificationTypes:UIRemoteNotificationTypeSound|UIRemoteNotificationTypeNewsstandContentAvailability|UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeAlert];
    
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    return YES;

}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    [UMSocialSnsService applicationDidBecomeActive];
}
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    return [UMSocialSnsService handleOpenURL:url wxApiDelegate:nil];
}

-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    
   
    //收到消息，传递给jpush 可以自己处理
    [APService handleRemoteNotification:userInfo];
}
//注册成功
-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    //注册成功后把token传递给jpush
    [APService registerDeviceToken:deviceToken];
    
}

@end
