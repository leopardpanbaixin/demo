#define OPERATION_URL  @"http://www.fanqie.com/activity/operation"
#define SURROUNDING_URL  @"http://www.fanqie.com/dishes/surrounding?city=1"

#define SUPPORTCITY_URL  @"http://www.fanqie.com/city/supportcity"

//关于我们
#define TQQ @"http://t.qq.com/fanqiekuaidian"
#define SinaWeibo @"http://weibo.com/fanqiekuaidian"



//豆果美食

#define WORK_DETAIL_URL @"http://api.douguo.net/recipe/dish/"








