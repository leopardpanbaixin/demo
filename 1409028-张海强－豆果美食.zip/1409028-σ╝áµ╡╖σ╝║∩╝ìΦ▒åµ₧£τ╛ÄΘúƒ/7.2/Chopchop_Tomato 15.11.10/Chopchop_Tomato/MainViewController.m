//
//  MainViewController.m
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "MainViewController.h"
#import "firstView.h"
#import "secondView.h"
#import "threeView.h"
#import "fourView.h"
#import "fiveView.h"
#import "sixView.h"

@interface MainViewController ()
{
    firstView *first;
    secondView *second;
    threeView *three;
    fourView *four;
    fiveView *five;
    sixView *six;
    
    UIView *tempView;
    
}
@end

@implementation MainViewController

- (void)dealloc
{
    [first release],first = nil;
    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.view.backgroundColor = [UIColor colorWithRed:250/256.0 green:246/256.0 blue:236/256.0 alpha:1];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    [self helpView];
    
}

- (void)helpView
{
    first = [[firstView alloc] init];
    tempView = first;
    [self.view addSubview:first];
    
    _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(nextAnimation:)];
    [self.view addGestureRecognizer:_tapGesture];
    [_tapGesture release];
}

- (void)nextAnimation:(UITapGestureRecognizer *)tap
{
    static NSInteger i = 1;
    NSArray *classNames = @[@"secondView",@"threeView",@"fourView",@"fiveView",@"sixView"];
    if (i < 6) {
        Class class = NSClassFromString(classNames[i-1]);
        UIView *view = [[class alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
        [tempView removeFromSuperview];
        tempView = view;
        [self.view addSubview:view];
        [view release];
        i++;
    }
    
    
//    [first removeFromSuperview];
//
//    second = [[secondView alloc] init];
//    [self.view addSubview:second];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
