//
//  HttpPostRequest.m
//  PostDemo
//
//  Created by Dove on 14-5-29.
//  Copyright (c) 2014年 Dove. All rights reserved.
//

#import "HttpPostRequest.h"

@implementation HttpPostRequest
{
    NSURLConnection *_urlConnection;
}

- (id)init
{
    self = [super init];
    if (self) {
        _downloadData = [[NSMutableData alloc] init];
    }
    return self;
}

- (void)dealloc
{
    [_urlConnection release];
    [_downloadData release];
    [super dealloc];
}

- (void) downloadDataWithUrlString:(NSString *)urlString requestMethod:(NSString *)method contentType:(NSString *)type paraDic:(NSDictionary *)dic
{
    //如果旧的连接存在,销毁
    if (_urlConnection) {
        [_urlConnection release],_urlConnection = nil;
    }
    
    NSURL *url = [NSURL URLWithString:urlString];
    //post请求用NSMutableURLRequest
    //请求地址作为可变request的请求头
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    //设置数据的请求方式
    [request setHTTPMethod:method];
    //设置请求参数的编码方式(作为请求头)
//    User-Agent: Dalvik/1.6.0 (Linux; U; Android 4.2.2; H30-T00 Build/HuaweiH30-T00) Paros/3.2.13
//    [request addValue:@"{}" forHTTPHeaderField:@"User-Agent"];
     [request addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    //将字典中的参数拼接成字符串连接的方式
    int i = 0;
    NSMutableString *bodyString = [NSMutableString string];
    //遍历字典（遍历key值）
    for (NSString *key in dic) {
        id obj = [dic objectForKey:key];
        if (i == 0) {
            [bodyString appendFormat:@"%@=%@",key,obj];
        } else {
            [bodyString appendFormat:@"&%@=%@",key,obj];
        }
        i++;
    }
    //将参数字符串转换成NSData
    NSData *data = [bodyString dataUsingEncoding:NSUTF8StringEncoding];
    //设置参数的长度
    [request addValue:[NSString stringWithFormat:@"%d",data.length] forHTTPHeaderField:@"Content-Length"];
    [request addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    //将参数的data作为请求体
    [request setHTTPBody:data];
    
    _urlConnection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
}

- (void) asiDownloadWithUrlString:(NSString *)urlStr requestMethod:(NSString *)method paraDic:(NSDictionary *)dic
{
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:urlStr]];
    //设置请求方式
    [request setRequestMethod:method];
    //设置代理
    request.delegate = self;
    //用ASIFormDataRequest,Content-Type和Content-Length可以缺省不写
    //字典中参数可能是普通参数，也可能是NSData（文件转换而成）
    for (NSString *key in dic) {
        id obj = [dic objectForKey:key];
        if ([obj isKindOfClass:[NSData class]]) {
            //需要上传文件
            //setData:图片转成的二进制数据
            //withFileName:文件的名称
            //andContentType:上传的文件的类型
            //forKey:文件对应的参数名称
            [request setData:obj withFileName:@"五粮液.png" andContentType:@"image/png" forKey:key];
        } else {
            //普通的参数 key = value
            [request addPostValue:obj forKey:key];
        }
    }
    //发起异步请求
    [request startAsynchronous];
}

#pragma mark - ASIHTTPRequestDelegate

- (void) requestFinished:(ASIHTTPRequest *)request
{
    if (request.responseData) {
        //将数据给到_downloadData
        [_downloadData setLength:0];
        [_downloadData appendData:request.responseData];
        if ([_delegate respondsToSelector:@selector(httpRequestFinished:)]) {
            [_delegate httpRequestFinished:self];
        }
    }
}

- (void) requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"%s",__FUNCTION__);
    NSLog(@"error:%@",[request.error description]);
    if ([_delegate respondsToSelector:@selector(httpRequestFailed:)]) {
        [_delegate httpRequestFailed:self];
    }
}

#pragma mark - NSURLConnectionDataDelegate

- (void) connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [_downloadData setLength:0];
}

- (void) connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [_downloadData appendData:data];
}

- (void) connectionDidFinishLoading:(NSURLConnection *)connection
{
    if (_downloadData) {
        if ([_delegate respondsToSelector:@selector(httpRequestFinished:)]) {
            [_delegate httpRequestFinished:self];
        }
    }
}

- (void) connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"%s",__FUNCTION__);
    NSLog(@"error:%@",error.localizedDescription);
    if ([_delegate respondsToSelector:@selector(httpRequestFailed:)]) {
        [_delegate httpRequestFailed:self];
    }
}

@end
