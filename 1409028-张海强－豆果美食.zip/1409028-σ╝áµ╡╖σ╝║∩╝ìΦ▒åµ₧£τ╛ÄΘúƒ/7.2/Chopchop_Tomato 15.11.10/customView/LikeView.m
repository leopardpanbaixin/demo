//
//  LikeView.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "LikeView.h"
#import "UIImageView+WebCache.h"

@implementation LikeView
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self _initView];
    }
    return self;
}
- (void)_initView
{
   
    
    imageView = [MyControl createImageViewFrame:CGRectMake(30, 0, 60, 60) imageName:nil];
    [self addSubview:imageView];
    
    
    imageView2 = [MyControl createImageViewFrame:CGRectMake(imageView.right+2, 0, 60, 60) imageName:nil];
    [self addSubview:imageView2];
    
    imageView3 = [MyControl createImageViewFrame:CGRectMake(imageView2.right+2, 0, 60, 60) imageName:nil];
    [self addSubview:imageView3];
    
    imageView4 = [MyControl createImageViewFrame:CGRectMake(imageView3.right+3, 0, 60, 60) imageName:nil];
    [self addSubview:imageView4];
 
}


- (void)configUI:(LikeModel *)model
{
    
    [imageView setImageWithURL:[NSURL URLWithString:model.images[0]]];
    [imageView2 setImageWithURL:[NSURL URLWithString:model.images[1]]];
    [imageView3 setImageWithURL:[NSURL URLWithString:model.images[2]]];
    [imageView4 setImageWithURL:[NSURL URLWithString:model.images[3]]];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
