//
//  TopicView.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "TopicView.h"
#import "UIImageView+WebCache.h"

@implementation TopicView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self _initView];
    }
    return self;
}

- (void)_initView
{
    label = [MyControl createLabelWithFrame:CGRectMake(10, 5, 150, 30) Font:12 Text:nil];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 2;
    [self addSubview:label];
    
    label1 = [MyControl createLabelWithFrame:CGRectMake(50, label.bottom + 2, 80, 14) Font:12 Text:nil];
    label1.textAlignment = NSTextAlignmentCenter;
    [self addSubview:label1];
    
    
    imageView = [MyControl createImageViewFrame:CGRectMake(20, label1.bottom+2, 60, 60) imageName:nil];
        [self addSubview:imageView];
    
    imageView1 = [MyControl createImageViewFrame:CGRectMake(90, label1.bottom+2, 60, 60) imageName:nil];
    [self addSubview:imageView1];
}
- (void)configUI:(TopicModel *)model
{
    label.text = [NSString stringWithFormat:@"#%@#",model.t];
    label.textColor = [UIColor brownColor];
    
    label1.text = [NSString stringWithFormat:@"%@",model.uc];
    label1.textColor = [UIColor grayColor];

  
    
    
    [imageView setImageWithURL:[NSURL URLWithString:[model.is firstObject]]];
    
    
    [imageView1 setImageWithURL:[NSURL URLWithString:[model.is lastObject]]];
    
    

    [model release];
}
@end
