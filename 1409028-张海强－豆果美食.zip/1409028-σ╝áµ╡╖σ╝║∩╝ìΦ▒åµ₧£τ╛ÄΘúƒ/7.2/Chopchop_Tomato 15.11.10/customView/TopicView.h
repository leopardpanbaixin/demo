//
//  TopicView.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TopicModel.h"

@interface TopicView : UIView {
    UILabel *label;
    UILabel *label1;
    UIImageView *imageView;
    UIImageView *imageView1;
}

- (void)configUI:(TopicModel *)model;
@end
