//
//  RootViewController.h
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-25.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MAMapKit/MAMapKit.h>
#import <AMapSearchKit/AMapSearchAPI.h>

@interface RootViewController : UIViewController <AMapSearchDelegate,MAMapViewDelegate,CLLocationManagerDelegate> {
    
    UIImageView *_threeImageView;
    UIImageView *_backgroundView;
    
//    用于定位指针
    CLLocationManager *_manager;
    
}
//存储城市id

@end
