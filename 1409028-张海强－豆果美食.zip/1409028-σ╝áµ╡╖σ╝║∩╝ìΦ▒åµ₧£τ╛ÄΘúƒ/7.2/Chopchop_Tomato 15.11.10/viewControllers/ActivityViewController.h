//
//  ActivityViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-30.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpPostRequest.h"
#import "PullTableView.h"

@interface ActivityViewController : UIViewController <HttpRequestDelegate,UITableViewDataSource,UITableViewDelegate,PullTableViewDelegate> {
    HttpPostRequest *_request;
    PullTableView *_pullTableView;
    int _page;
}

@property (nonatomic,retain) NSMutableArray *dataArray;
@property (nonatomic,retain) NSMutableDictionary *dataDictionary;
@end
