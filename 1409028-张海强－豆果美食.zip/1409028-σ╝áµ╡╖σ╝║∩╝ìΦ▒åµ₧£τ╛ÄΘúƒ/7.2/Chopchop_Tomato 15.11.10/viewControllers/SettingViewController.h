//
//  SettingViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-27.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController

@property (nonatomic,copy) NSString *city;
- (IBAction)locationClick:(id)sender;
@property (retain, nonatomic) IBOutlet UILabel *LocationLabel;
- (IBAction)loginButtonClick:(id)sender;
- (IBAction)feedbackClick:(id)sender;
- (IBAction)updateClick:(id)sender;
- (IBAction)aboutClick:(id)sender;
- (IBAction)soundClick:(id)sender;
- (IBAction)pushClick:(id)sender;

@end
