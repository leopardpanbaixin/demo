//
//  ActivityViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-30.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ActivityViewController.h"
#import "ActivityModel.h"
#import "ActivityCell.h"
#import "UIImageView+WebCache.h"
#import "ActivityDetailViewController.h"

@interface ActivityViewController ()

@end

@implementation ActivityViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
         self.view.backgroundColor = [UIColor colorWithRed:224/256.0 green:215/256.0 blue:194/256.0 alpha:1];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _dataArray = [[NSMutableArray alloc]init];
    [self createNav];
    [self createTableView];
    [self loadData];
}
#pragma mark 获得数据
- (void)loadData
{
    _request = [[HttpPostRequest alloc]init];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"4",@"client",@"f8d0f90490e007a607df48a6d877cf9e",@"sign_ran",@"0101031565abc8bc",@"code",nil];
    
    [_request asiDownloadWithUrlString:@"http://api.douguo.net/activity/lists/0/30" requestMethod:@"POST" paraDic:dic];
    _request.delegate = self;
}
- (void) httpRequestFinished:(HttpPostRequest *)request
{
    
    if (request.downloadData) {
        id result = [NSJSONSerialization JSONObjectWithData:request.downloadData options:NSJSONReadingMutableContainers error:nil];
        if (_page == 1) {
            [self.dataArray removeAllObjects];
        }
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dataDic = (NSDictionary *)result;
            NSArray *array = [[dataDic objectForKey:@"result"] objectForKey:@"activities"];
          
            for (NSDictionary *dataDic in array) {
                ActivityModel *model = [[ActivityModel alloc] init];
                [model setValuesForKeysWithDictionary:dataDic];
                [self.dataArray addObject:model];
                [model release];
            }
            [_pullTableView reloadData];
        }
    }
}

- (void) httpRequestFailed:(HttpPostRequest *)request
{
    
}
#pragma mark 创建tableView
- (void)createTableView
{
    _pullTableView = [[PullTableView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight - [MyControl isIOS7]) style:UITableViewStylePlain];
    _pullTableView.pullDelegate = self;
    _pullTableView.delegate = self;
    _pullTableView.dataSource = self;
    _pullTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _pullTableView.pullArrowImage = [UIImage imageNamed:@"blackArrow"];
    _pullTableView.pullBackgroundColor = [UIColor whiteColor];
    _pullTableView.pullTextColor = [UIColor blackColor];
    [self.view addSubview:_pullTableView];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 190;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ActivityCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"ActivityCell" owner:self options:nil] lastObject];
        cell.backgroundColor = [UIColor colorWithRed:224/256.0 green:215/256.0 blue:194/256.0 alpha:0.6];
        
    }
    ActivityModel *model = self.dataArray[indexPath.row];
    cell.nameLabel.text = model.name;
    cell.timeLabel.text = model.end_date;
    [cell.activityImageView setImageWithURL:[NSURL URLWithString:model.image]];
    cell.ActivityLabel.text = model.type;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ActivityModel *model = self.dataArray[indexPath.row];
    ActivityDetailViewController *detail = [[ActivityDetailViewController alloc] init];
    detail.urlStr = model.url;
    [self.navigationController pushViewController:detail animated:YES];
    [detail release];
}
#pragma mark pullDelegate的代理
- (void)pullTableViewDidTriggerRefresh:(PullTableView *)pullTableView{
    NSLog(@"pull to refresh...");
    [self performSelector:@selector(refreshTable) withObject:nil afterDelay:1.0f];
}
- (void)pullTableViewDidTriggerLoadMore:(PullTableView *)pullTableView{
    NSLog(@"pull to loadmore...");
    [self performSelector:@selector(loadMoreDataToTable) withObject:nil afterDelay:1.0f];
}
- (void)refreshTable{
    _pullTableView.pullTableIsRefreshing = NO;
    _pullTableView.pullLastRefreshDate = [NSDate date];
    _page = 1;
    [self loadData];
}
- (void)loadMoreDataToTable{
    _pullTableView.pullTableIsLoadingMore = NO;
    _page ++;
    [self loadData];
}

#pragma mark 导航
- (void)createNav
{
    self.navigationController.navigationBar.translucent = NO;
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"juchi.png"] forBarMetrics:UIBarMetricsDefault];
    
    self.navigationItem.title = @"活动";
    [self createNavButton];
}

- (void)createNavButton
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
}

- (void)leftButtonClick
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
