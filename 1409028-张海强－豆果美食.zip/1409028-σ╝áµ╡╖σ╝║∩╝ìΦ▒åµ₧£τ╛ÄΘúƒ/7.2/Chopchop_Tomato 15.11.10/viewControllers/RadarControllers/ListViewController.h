//
//  ListViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-30.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpPostRequest.h"

@interface ListViewController : UIViewController <UIScrollViewDelegate,HttpRequestDelegate> {
    HttpPostRequest *_request;
    UIScrollView *_backgroundScrollView;
    UIScrollView *_imageScrollView;
    UIButton *_button;
    UIPageControl *_page;
    UIButton *_scrollButton;
    
    UILabel *_buttonsLabel;
    
    UIButton *_button1;
    UIButton *_button2;
    
//    view
    
    UIView *_topicView;
    UIView *_likeView;
    UIView *_fashionView;
}

@property (nonatomic,retain) NSMutableArray *dataArray;
@property (nonatomic,retain) NSMutableArray *buttonArray;
@property (nonatomic,retain) NSMutableArray *scrollArray;
@property (nonatomic,retain) NSMutableArray *topicArray;
@property (nonatomic,retain) NSMutableArray *likeArray;
@property (nonatomic,retain) NSMutableArray *bottomArray;

@end
