//
//  ListViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-30.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ListViewController.h"
#import "WeeklyViewController.h"
#import "UIButton+WebCache.h"
#import "ScrollModel.h"
#import "ButtonsModel.h"
#import "TopicModel.h"
#import "LikeModel.h"
#import "BottomModel.h"
#import "TopicView.h"
#import "LikeView.h"
#import "ButtonViewController.h"
#import "MoreViewController.h"
#import "PersonViewController.h"
#import "SaleViewController.h"
#import "UIImageView+WebCache.h"
#import "TopicDetailViewController.h"

@interface ListViewController ()

@end

@implementation ListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
         self.view.backgroundColor = [UIColor colorWithRed:224/256.0 green:215/256.0 blue:194/256.0 alpha:1];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataArray = [[NSMutableArray alloc] init];
    self.buttonArray = [[NSMutableArray alloc] init];
    self.scrollArray = [[NSMutableArray alloc] init];
    self.topicArray = [[NSMutableArray alloc] init];
    self.likeArray = [[NSMutableArray alloc] init];
    self.bottomArray = [[NSMutableArray alloc] init];
    
     [self createNav];
    
     [self configUI];
     [self loadData];
    
}
- (void)loadData
{
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"4",@"client",@"f07f14ae192334e8b51b017e72ba95f2",@"sign_ran",@"63d701274da8209e",@"code",nil];
    _request = [[HttpPostRequest alloc]init];
    [_request asiDownloadWithUrlString:@"http://api.douguo.net/recipe/recomm" requestMethod:@"POST" paraDic:dic];
    _request.delegate = self;
}

- (void) httpRequestFinished:(HttpPostRequest *)request
{
    
    if (request.downloadData) {
        id result = [NSJSONSerialization JSONObjectWithData:request.downloadData options:NSJSONReadingMutableContainers error:nil];
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dataDic = (NSDictionary *)result;
          
         NSArray *scroll = [[dataDic objectForKey:@"result"] objectForKey:@"top_headlines"];
          
            for (NSDictionary *dic in scroll) {
                
                ScrollModel *model = [[ScrollModel alloc] init];
                [model setValuesForKeysWithDictionary:dic];
                [self.scrollArray addObject:model];
               
            }
            
        NSArray *eight = [[dataDic objectForKey:@"result"] objectForKey:@"specials"];
            for (NSDictionary *dic in eight) {
                ButtonsModel *model = [[ButtonsModel alloc] init];
                [model setValuesForKeysWithDictionary:dic];
                [self.buttonArray addObject:model];
            }
            
            NSArray *tags = [[dataDic objectForKey:@"result"] objectForKey:@"tags"];
            for (NSDictionary *dic in tags) {
                LikeModel *model = [[LikeModel alloc] init];
                [model setValuesForKeysWithDictionary:dic];
                [self.likeArray addObject:model];
            }
            
            NSArray *bArray = [[dataDic objectForKey:@"result"] objectForKey:@"bottom_headlines"];
            for (NSDictionary *dic in bArray) {
                BottomModel *model = [[BottomModel alloc] init];
                [model setValuesForKeysWithDictionary:dic];
                [self.bottomArray addObject:model];
            }
            
            
            NSArray *topic = [[dataDic objectForKey:@"result"] objectForKey:@"dts"];
            for (NSDictionary *dic in topic) {
                TopicModel *model = [[TopicModel alloc] init];
                [model setValuesForKeysWithDictionary:dic];
                [self.topicArray addObject:model];
            }
            
            
            [self updateUI];
        }
    }
}

- (void) updateUI
{
    
//   更新buttons的图片
//    int j = 0;
//    for (UIButton *btn in _buttonsView.subviews) {
//            ButtonsModel *model = _buttonArray[j];
//            [btn setImageWithURL:[NSURL URLWithString:model.image_url]];
//        j++;
//        if (j==7) {
//            break;
//        }
//    }
    
//    int k = 0;
//    for (UILabel *label in _likeView.subviews) {
//        
//            ButtonsModel *model = _buttonArray[k];
//            label.text = [NSString stringWithFormat:@"%@",model.name];
//             k++;
//        if (k==7) {
//            break;
//        }
//    }
    //更新scroll的图片
    int i = 0;
    for (UIButton *btn in _imageScrollView.subviews) {
        if (i == _scrollArray.count) {
            break;
        }
        ScrollModel *model = _scrollArray[i];
        [btn setImageWithURL:[NSURL URLWithString:model.image_url]];
        i++;
        
    }
//    更新话题
    int a = 0;
    for (id sender in _topicView.subviews) {
       
        if ([sender isKindOfClass:[TopicView class]]) {
            TopicView *view = (TopicView *)sender;
            TopicModel *model = _topicArray[a];
            [view configUI:model];
            a++;
        }
    }
//    喜好
    int b = 0;
    for (id sender in _likeView.subviews) {
        if ([sender isKindOfClass:[LikeView class]]) {
            LikeView *view = (LikeView *)sender;
            LikeModel *model = _likeArray[b];
            [view configUI:model];
            b++;
        }
    }
    
//    更新底部图片
//    BottomModel *model = [self.bottomArray firstObject];
//    [_button1 setImageWithURL:[NSURL URLWithString:model.image_url]];
//    BottomModel *model1 = [self.bottomArray lastObject];
//    [_button2 setImageWithURL:[NSURL URLWithString:model1.image_url]];
}

- (void) httpRequestFailed:(HttpPostRequest *)request
{
    
}

#pragma mark 布局UI
- (void)configUI
{
//    第一步
//    [self createSearchBar];
//    底部scrollView
    _backgroundScrollView  = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    _backgroundScrollView.showsHorizontalScrollIndicator = YES;
    _backgroundScrollView.contentSize = CGSizeMake(ScreenWidth, ScreenHeight*3 - 180);
    _backgroundScrollView.bounces = NO;
    [self.view addSubview:_backgroundScrollView];
    
//   buttons
    [self createButtons];
//   labels
    [self createLabels];
//    创建friendButton
    [self createFriendButton];
//    创建小的scrollView

    [self createScrollView];
//    创建小button

    UIImageView *xdImageView = [MyControl createImageViewFrame:CGRectMake(10, 310, 300, 80) imageName:nil];
    [xdImageView setImageWithURL:[NSURL URLWithString:@"http://cp1.douguo.net/upload/banner/b/4/c/b41eec50b0cbcf83b157d4e283600d5c.jpg"]];
    [_backgroundScrollView addSubview:xdImageView];
    UILabel *label = [MyControl createLabelWithFrame:CGRectMake(10, 400, 300, 20) Font:16 Text:@"大家都在参与的话题"];
//    label.backgroundColor = [UIColor redColor];
    label.textColor = [UIColor grayColor];
    [_backgroundScrollView addSubview:label];

//    创建话题button
    [self createTopicButtons];
    UILabel *label1 = [MyControl createLabelWithFrame:CGRectMake(10, 700, 300, 25) Font:18 Text:@"猜你喜欢"];
    label1.textColor = [UIColor grayColor];
    [_backgroundScrollView addSubview:label1];

    //    创建喜欢
    [self createLikeButtons];
//    创建流行 fashion以及super
    [self createFashionButtons];
}
#pragma mark createFashionButtons
- (void)createFashionButtons
{
    _fashionView = [[UIView alloc] initWithFrame:CGRectMake(0, 1075, 320, 110)];
    [_backgroundScrollView addSubview:_fashionView];
    
    
    _button1 = [MyControl createButtonWithFrame:CGRectMake(10, 10, 140, 100) target:self SEL:@selector(leftButtonClick1) title:nil imageName:nil bgImageName:@"headline_bg_left.png"];
    
    [_button1 setImageWithURL:[NSURL URLWithString:@"http://i1.douguo.net/upload/banner/6/e/a/6ebecb869c4acc320b0a89706a3afe0a.jpg"]];
   
    [_fashionView addSubview:_button1];
    _button2 = [MyControl createButtonWithFrame:CGRectMake(170, 10, 140, 100) target:self SEL:@selector(rightButtonClick) title:nil imageName:nil bgImageName:@"headline_bg_left.png"];
   
     [_button2 setImageWithURL:[NSURL URLWithString:@"http://i1.douguo.net/upload/banner/3/b/8/3bb1d59c4cf71d3a97b67e2a7e971478.jpg"]];
    [_fashionView addSubview:_button2];
    
}
- (void)rightButtonClick
{
    
}
- (void)leftButtonClick1
{
    
}
#pragma mark 喜欢
- (void)createLikeButtons
{
    _likeView = [[UIView alloc] initWithFrame:CGRectMake(0, 725, 320, 70*5)];
    [_backgroundScrollView addSubview:_likeView];

    for (int i=0; i<5; i++) {
  
        LikeView *view1 = [[LikeView alloc] initWithFrame:CGRectMake(0,10 + (i*70), 300, 60)];

        [_likeView addSubview:view1];
        
        UIControl *control = [[UIControl alloc] initWithFrame:CGRectMake(0,10 + (i*70), 300, 60)];
        control.tag = 2201+i;
        [_likeView addSubview:control];
        [control addTarget:self action:@selector(likeButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    }

}

- (void)likeButtonClick:(UIControl *)control
{
    int tag = control.tag - 2201;
    switch (tag) {
        case 0:
        {
            ButtonViewController *btn = [[ButtonViewController alloc] init];
            btn.text = @"世界杯";
            btn.sign_ran = @"f0a5849ab30368f6877a72c9d90e15c4";
            btn.code = @"1daee9431040cc41";
            [self.navigationController pushViewController:btn animated:YES];
            [btn release];
        }
            break;
         
        case 1:
        {
            ButtonViewController *btn = [[ButtonViewController alloc] init];
            btn.text = @"冰品";
            btn.sign_ran = @"a4a93da37ab74c30b0b427319dad9a8b";
            btn.code = @"fc9a57ac2a456953";
            [self.navigationController pushViewController:btn animated:YES];
            [btn release];
        }
            break;
        case 2:
        {
            ButtonViewController *btn = [[ButtonViewController alloc] init];
            btn.text = @"冰激凌";
            btn.sign_ran = @"91634ec5a9cf9ad2ea8b0f0a4a8b306f";
            btn.code = @"ca2d6600a7e96603";
            [self.navigationController pushViewController:btn animated:YES];
            [btn release];
        }
            break;
        case 3:
        {
            ButtonViewController *btn = [[ButtonViewController alloc] init];
            btn.text = @"甜品";
            btn.sign_ran = @"40cabbc00cece4c5a6fc70659eb7bc64";
            btn.code = @"ee01b555404d0fce";
            [self.navigationController pushViewController:btn animated:YES];
            [btn release];
        }
            break;
        case 4:
        {
            ButtonViewController *btn = [[ButtonViewController alloc] init];
            btn.text = @"戚风蛋糕";
            btn.sign_ran = @"f3ddf192f3c0ef13a9ad906388ecdeb8";
            btn.code = @"8373d693abe1604b";
            [self.navigationController pushViewController:btn animated:YES];
            [btn release];
        }
            break;
        default:
            break;
    }
}
#pragma mark 话题
- (void)createTopicButtons
{
    _topicView = [[UIView alloc] initWithFrame:CGRectMake(0, 420, 320, 280)];
   
    [_backgroundScrollView addSubview:_topicView];
    for (int i=0; i<4; i++) {
        TopicView *view = [[TopicView alloc] initWithFrame:CGRectMake((i%2)*150, (i/2)*140, 140, 130)];
        
        [_topicView addSubview:view];
        
        
        UIControl *control = [[UIControl alloc] initWithFrame:CGRectMake(20+(i%2)*150, (i/2)*140, 140, 130)];
        [_topicView addSubview:control];
       
    }
}

#pragma mark scrollView
- (void)createScrollView
{
    _imageScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 160, ScreenWidth, 140)];
//    _imageScrollView.backgroundColor = [UIColor greenColor];
    _imageScrollView.contentSize = CGSizeMake(320*2, 100);
    _imageScrollView.showsHorizontalScrollIndicator = NO;
    _imageScrollView.showsVerticalScrollIndicator = NO;
    
        _imageScrollView.contentOffset = CGPointMake(320, 0);
    _imageScrollView.delegate = self;
    //    关闭反弹
    _imageScrollView.bounces = NO;
    _imageScrollView.pagingEnabled = YES;
    [_backgroundScrollView addSubview:_imageScrollView];

#warning leopard更改imageScrollView里面的内容3----->2
    for (int i=0; i<2; i++) {
        for (int j=0; j<2; j++) {
            _scrollButton = [MyControl createButtonWithFrame:CGRectMake(14+(j%2)*160+(320*i), 20, 130, 100) target:nil SEL:nil title:nil imageName:nil bgImageName:nil];
            _scrollButton.showsTouchWhenHighlighted = YES;
            _scrollButton.layer.cornerRadius = 5;
            _scrollButton.layer.masksToBounds = YES;
            [_imageScrollView addSubview:_scrollButton];
            
        }
    }

    _page = [[UIPageControl alloc] initWithFrame:CGRectMake(100, 290, 120, 20)];
//    _page.backgroundColor = [UIColor orangeColor];
    _page.numberOfPages = 2;
    _page.currentPage = 0;
    _page.pageIndicatorTintColor = [UIColor whiteColor];
    _page.currentPageIndicatorTintColor = [UIColor brownColor];
    [_backgroundScrollView addSubview:_page];
}

#pragma mark - 中间scrollView图片
-(void) scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView == _imageScrollView) {
        _page.currentPage = scrollView.contentOffset.x / 320;
    
    }
    
}
- (void)createFriendButton
{
    UIImageView *view1 = [MyControl createImageViewFrame:CGRectMake(15, 140, 10, 15) imageName:@"discovery_feeds"];
    [_backgroundScrollView addSubview:view1];
    UILabel *label = [MyControl createLabelWithFrame:CGRectMake(35, 140, 250, 20) Font:12 Text:@"好友动态"];
    [_backgroundScrollView addSubview:label];
    UIImageView *view2 = [MyControl createImageViewFrame:CGRectMake(290, 140, 10, 20) imageName:@"cm_right.png"];
    [_backgroundScrollView addSubview:view2];
    UIControl *control = [[UIControl alloc] initWithFrame:CGRectMake(0, 140, ScreenWidth, 20)];
//    control.backgroundColor = [UIColor blueColor];
    control.alpha = 0.4;
    [_backgroundScrollView addSubview:control];
    [control addTarget:self action:@selector(friendsClick) forControlEvents:UIControlEventTouchUpInside];
}
- (void)friendsClick
{
    PersonViewController *person = [[PersonViewController alloc] init];
    [self presentViewController:person animated:YES completion:nil];
}

#pragma mark 8个Buttons
- (void)createButtons
{
    for (int i=0; i<8; i++) {
        if (i==7) {
                        _button = [MyControl createButtonWithFrame:CGRectMake(35+(i%4)*70, 10+(i/4)*65, 40, 40) target:self SEL:@selector(moreButtonClick:) title:nil imageName:nil bgImageName:@"folded_like_users.png" ];
            
        } else if (i == 4) {
            _button = [MyControl createButtonWithFrame:CGRectMake(35+(i%4)*70, 10+(i/4)*65, 40, 40) target:self SEL:@selector(moreButtonClick:) title:nil imageName:nil bgImageName:@"genius_b_fruit.png"];
            _button.backgroundColor = [UIColor colorWithRed:169/256.0 green:179/256.0 blue:75/255.0 alpha:1];
        }
        else {
            _button = [MyControl createButtonWithFrame:CGRectMake(35+(i%4)*70, 10+(i/4)*65, 40, 40) target:self SEL:@selector(moreButtonClick:) title:nil imageName:nil bgImageName:@"genius_b_bean.png"];
            _button.backgroundColor = [UIColor colorWithRed:169/256.0 green:179/256.0 blue:75/255.0 alpha:1];
        }
        
        _button.tag = 2214+i;
        
        _button.layer.cornerRadius = 20.0;
        _button.layer.masksToBounds = YES;
        [_backgroundScrollView addSubview:_button];
       
        
    }
}
- (void)createLabels
{
    
    for (int i=0; i<8; i++) {
        if (i==7) {
            _buttonsLabel = [MyControl createLabelWithFrame:CGRectMake(42+(i%4)*70 , 50+(i/4)*65, 40, 15) Font:12 Text:nil];

        } else {
            _buttonsLabel = [MyControl createLabelWithFrame:CGRectMake(42+(i%4)*70 , 50+(i/4)*65, 40, 15) Font:12 Text:nil];
        }
        if (i==0) {
            _buttonsLabel.text = @"油麦菜";
        }
        if (i==1) {
            _buttonsLabel.text = @"苋菜";
        }
        if (i==2) {
            _buttonsLabel.text = @"洋葱";
        }
        if (i==3) {
            _buttonsLabel.text = @"蕨菜";
        }
        if (i==4) {
            _buttonsLabel.text = @"芒果";
        }
        if (i==5) {
            _buttonsLabel.text = @"空心菜";
        }
        if (i==6) {
            _buttonsLabel.text = @"茭白";
        }
        if (i==7) {
            _buttonsLabel.text = @"更多";
        }
         [_backgroundScrollView addSubview:_buttonsLabel];
    }
}
- (void)moreButtonClick:(UIButton *)button
{
    if (self.buttonArray.count>0) {
        switch (button.tag-2214) {
            case 0:
            {
                ButtonViewController *vc=[[ButtonViewController alloc]init];
                vc.sign_ran = @"a8196e396dfd6d58ae86470c3f3e3b6b";
                vc.code = @"bcd879df10773d7e";
                vc.text = @"油麦菜";
                [self.navigationController pushViewController:vc animated:YES];
                [vc release];
            }
                break;
            case 1:
            {
                ButtonViewController *vc=[[ButtonViewController alloc]init];
                vc.sign_ran = @"f110e6e5164b071cfa7576c969989c5f";
                vc.code = @"fa3cb3c74061b90d";
                vc.text = @"苋菜";
                [self.navigationController pushViewController:vc animated:YES];
                [vc release];
            }
                break;
            case 2:
            {
                ButtonViewController *vc=[[ButtonViewController alloc]init];
                vc.sign_ran = @"4ceb646ec6e4ce3e841ed9b7ef056f49";
                vc.code = @"7469a11d71e952a2";
                vc.text = @"洋葱";
                [self.navigationController pushViewController:vc animated:YES];
                [vc release];
            }
                break;
            case 3:
            {
                ButtonViewController *vc=[[ButtonViewController alloc]init];
                vc.sign_ran = @"35856909fade25afb52e398f623502a9";
                vc.code = @"ca567c1f71900cb3";
                vc.text = @"蕨菜";
                [self.navigationController pushViewController:vc animated:YES];
                [vc release];
            }
                break;
            case 4:
            {
                ButtonViewController *vc=[[ButtonViewController alloc]init];
                vc.sign_ran = @"d931d4f150bb8e05a9b8aec219bca00a";
                vc.code = @"393691f1f93614a3";
                vc.text = @"芒果";
                [self.navigationController pushViewController:vc animated:YES];
                [vc release];
            }
                break;
            case 5:
            {
                ButtonViewController *vc=[[ButtonViewController alloc]init];
                vc.sign_ran = @"e43fdc0a844408a9511f13a21891d539";
                vc.code = @"f0ece7d5212d6323";
                vc.text = @"空心菜";
                [self.navigationController pushViewController:vc animated:YES];
                [vc release];
            }
                break;
            case 6:
            {
                ButtonViewController *vc=[[ButtonViewController alloc]init];
                vc.sign_ran = @"5a79671051f72ef6863cd5c25524be7a";
                vc.code = @"c39ad903befc6c12";
                vc.text = @"茭白";
                [self.navigationController pushViewController:vc animated:YES];
                [vc release];
            }
                break;
            case 7:
            {
                MoreViewController *vc1=[[MoreViewController alloc]init];
                [self.navigationController pushViewController:vc1 animated:YES];
                [vc1 release];
            }
                break;
            default:
                break;
        }

    }
}

#pragma mark 创建导航栏
- (void)createNav
{
    self.navigationController.navigationBar.translucent = NO;
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"juchi.png"] forBarMetrics:UIBarMetricsDefault];
    
    self.navigationItem.title = @"豆果美食";
    [self createNavButton];
}

- (void)createNavButton
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
}

- (void)leftButtonClick
{
    [self.navigationController popViewControllerAnimated:YES];
}



@end
