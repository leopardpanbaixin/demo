//
//  AboutUSViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUSViewController : UIViewController

- (IBAction)sinaClick:(id)sender;

- (IBAction)qqClick:(id)sender;

@end
