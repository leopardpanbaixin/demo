//
//  WeeklyViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "WeeklyViewController.h"

@interface WeeklyViewController ()

@end

@implementation WeeklyViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    // Do any additional setup after loading the view.
    [self createNav];
    _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-[MyControl isIOS7])];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.fanqie.com/activity/cateweekly"]];
        [_webView loadRequest:request];
     [(UIScrollView *)[[_webView subviews] lastObject]setBounces:NO];
    [self.view addSubview:_webView];
    [_webView release];

}
- (void)createNav
{
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"juchi"] forBarMetrics:UIBarMetricsDefault];
    self.navigationItem.title = @"美食周刊";
    [self createNavButton];
}

- (void)createNavButton
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
}

- (void)leftButtonClick
{
    [_webView removeFromSuperview];
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
