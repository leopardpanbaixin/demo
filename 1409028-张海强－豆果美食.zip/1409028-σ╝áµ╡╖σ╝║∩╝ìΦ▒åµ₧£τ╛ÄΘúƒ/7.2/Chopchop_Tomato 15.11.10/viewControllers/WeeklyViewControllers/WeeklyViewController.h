//
//  WeeklyViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeeklyViewController : UIViewController
{
    UIWebView *_webView;
}

@property (nonatomic,copy) NSString *urlStr;

@end
