//
//  SinaViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SinaViewController : UIViewController <UIWebViewDelegate>
{
    UIWebView *_webView;
    UIActivityIndicatorView *_activityIndicator;
    UIView *_tView;
    
}

@property (nonatomic,copy) NSString *urlStr;

@end
