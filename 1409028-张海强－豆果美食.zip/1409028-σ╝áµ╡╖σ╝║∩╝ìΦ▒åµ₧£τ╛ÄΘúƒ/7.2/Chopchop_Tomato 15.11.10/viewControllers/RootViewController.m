//
//  RootViewController.m
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-25.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "RootViewController.h"
#import "ListViewController.h"
#import "SettingViewController.h"
#import "PersonViewController.h"
#import "WeeklyViewController.h"
#import "ActivityViewController.h"
#import "WorkViewController.h"
#import "MoreViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (void)dealloc
{
    [_backgroundView release],_backgroundView = nil;
    [_threeImageView release],_backgroundView = nil;
    [_manager release];
    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.

    [self createNav];
    
    [self createUI];
    
    [self createLocation];
    
//    反地理编码
    [self ReGeocode];
    
}


- (void)ReGeocode
{
//    需要初始化搜索SDKAPI
    AMapSearchAPI *search = [[AMapSearchAPI alloc] initWithSearchKey:@"8bec732862afb9dbbffe0b34fe533c2c" Delegate:self];
    //反地理
    AMapReGeocodeSearchRequest*request1=[[AMapReGeocodeSearchRequest alloc]init];
    //设置反地理半径
    request1.radius=1000;
    //设置搜索类型
    request1.searchType=AMapSearchType_ReGeocode;
    //设置位置
  
    //设置是否返回周边信息
    request1.requireExtension=YES;
    [search AMapReGoecodeSearch:request1];
    [search release];
    [request1 release];
}

//反向地理结果
-(void)onReGeocodeSearchDone:(AMapReGeocodeSearchRequest *)request response:(AMapReGeocodeSearchResponse *)response
{
    //获得地址
    NSLog(@"%@",response.regeocode.formattedAddress);
}

- (void)createView
{
    UILabel *label = [MyControl createLabelWithFrame:CGRectMake(120, 55, 70, 20) Font:16 Text:@"豆果美食"];
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont boldSystemFontOfSize:16];
    [self.view addSubview:label];
    UILabel *subLabel = [MyControl createLabelWithFrame:CGRectMake(120, 70, 70, 20) Font:10 Text:@"为你寻找美食"];
    subLabel.textColor = [UIColor whiteColor];
    [self.view addSubview:subLabel];
    
    UILabel *label1 = [MyControl createLabelWithFrame:CGRectMake(50, 115, 80, 20) Font:16 Text:@"美食探测器"];
    label1.textColor = [UIColor whiteColor];
    label1.font = [UIFont boldSystemFontOfSize:16];
    [self.view addSubview:label1];
    UILabel *subLabel1 = [MyControl createLabelWithFrame:CGRectMake(60, 135, 60, 20) Font:10 Text:@"查看全部信息"];
    subLabel1.textColor = [UIColor whiteColor];
    [self.view addSubview:subLabel1];
    
    UILabel *label2 = [MyControl createLabelWithFrame:CGRectMake(70, 190, 40, 20) Font:16 Text:@"作品"];
    label2.textColor = [UIColor whiteColor];
    label2.font = [UIFont boldSystemFontOfSize:16];
    [self.view addSubview:label2];
    UILabel *subLabel2 = [MyControl createLabelWithFrame:CGRectMake(68, 210, 40, 20) Font:10 Text:@"高 大 上"];
    subLabel2.textColor = [UIColor whiteColor];
    [self.view addSubview:subLabel2];
    
    UILabel *label3 = [MyControl createLabelWithFrame:CGRectMake(83, 270, 40, 30) Font:16 Text:@"活动"];
    label3.textColor = [UIColor whiteColor];
    label3.font = [UIFont boldSystemFontOfSize:16];
    [self.view addSubview:label3];
    UILabel *subLabel3 = [MyControl createLabelWithFrame:CGRectMake(78, 290, 40, 30) Font:10 Text:@"活动详情"];
    subLabel3.textColor = [UIColor whiteColor];
    [self.view addSubview:subLabel3];
    
    UILabel *label4 = [MyControl createLabelWithFrame:CGRectMake(104, 335, 70, 20) Font:16 Text:@"美食周刊"];
    label4.textColor = [UIColor whiteColor];
    label4.font = [UIFont boldSystemFontOfSize:16];
    [self.view addSubview:label4];
    UILabel *subLabel4 = [MyControl createLabelWithFrame:CGRectMake(95, 355, 120, 20) Font:10 Text:@"小番带你搜罗美食"];
    subLabel4.textColor = [UIColor whiteColor];
    [self.view addSubview:subLabel4];
}
- (void)createLocation
{
    _manager = [[CLLocationManager alloc] init];
//    设置代理
    _manager.delegate = self;
    
    _manager.desiredAccuracy = kCLLocationAccuracyBest;
//    设置定位精度
    _manager.distanceFilter = 1000;
//    开始定位
    [_manager startUpdatingLocation];
    
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *newLocation = [locations lastObject];
    
    //如何获得经纬度
    NSLog(@"%f~~%f",newLocation.coordinate.latitude,newLocation.coordinate.longitude);
    
    [manager stopUpdatingLocation];
}
- (void)createNav
{
    //    设置导航栏的背景图片
    self.navigationController.navigationBar.translucent = NO;
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"juchi.png"] forBarMetrics:UIBarMetricsDefault];

    //    设置导航标题
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 144, 44)];
    UIImageView *imageView = [MyControl createImageViewFrame:CGRectMake(20, 7, 30, 30) imageName:@"navbar_title_tomato.png"];
    [titleView addSubview:imageView];
    UILabel *titleLabel = [MyControl createLabelWithFrame:CGRectMake(52, 2, 100, 40) Font:20 Text:@"豆果"];
    [titleView addSubview:titleLabel];
    self.navigationItem.titleView = titleView;
    [titleView release];
    //    设置导航按钮
    [self createNavButtons];
}
- (void)createNavButtons
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"navbar_people"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"navbar_people_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
    
    //    创建右导航
    UIButton *rightButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(rightButtonClick) title:nil imageName:nil bgImageName:nil];
    [rightButton setBackgroundImage:[UIImage imageNamed:@"navbar_set"]  forState:UIControlStateNormal];
    [rightButton setBackgroundImage:[UIImage imageNamed:@"navbar_set_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    self.navigationItem.rightBarButtonItem = rightItem;
    [rightItem release];
}

- (void)rightButtonClick
{
    SettingViewController *setting = [[SettingViewController alloc] init];
    [self.navigationController pushViewController:setting animated:YES];
    [setting release];
}
- (void)leftButtonClick
{
    PersonViewController *person = [[PersonViewController alloc] init];
    [self presentViewController:person animated:YES completion:nil];
    [person release];
}
- (void)createUI
{
    //   背景第一层
    _backgroundView = [MyControl createImageViewFrame:self.view.frame imageName:@"radarBlurBg.png"];
    [self.view addSubview:_backgroundView];
    
    //    背景第二层
    UIImageView *secondImageView = [MyControl createImageViewFrame:CGRectMake(ScreenWidth-146, (ScreenHeight-241)/2-30, 146, 241) imageName:@"main_dish_ex.png"];
    [_backgroundView addSubview:secondImageView];
    
    //   背景第三层
    _threeImageView = [MyControl createImageViewFrame:CGRectMake(ScreenWidth-178, (ScreenHeight-309)/2-30, 178, 309) imageName:@"main_dish_cricle.png"];
    [_backgroundView addSubview:_threeImageView];
    [self animationOfCAKeyframeAnimationPath];
}
- (void)animationOfCAKeyframeAnimationPath
{
    NSArray *ImageArray = @[@"main_leida_icon",@"main_dishscan_icon",@"main_res_icon",@"main_notelist_icon",@"main_shiji_icon@2xicon.png"];
    
    for (int i=0; i<ImageArray.count; i++) {
        
        UIButton *customButton = [MyControl createButtonWithFrame:CGRectMake(100, 100, 60, 60) target:self SEL:@selector(buttonClick:) title:nil imageName:ImageArray[i] bgImageName:@"main_btn_bg.png"];
        
        customButton.tag = 2014+i;
        [_backgroundView addSubview:customButton];
        
        CAKeyframeAnimation *ani = [CAKeyframeAnimation animation];
        //初始化路径
        CGMutablePathRef aPath = CGPathCreateMutable();
        //动画起始点
        CGPathMoveToPoint(aPath, nil, _threeImageView.right-20, _threeImageView.bottom+10);
        
        
        if (i>=0 && i<=1) {
            
            CGPathAddCurveToPoint(aPath, nil,
                                  _threeImageView.right-280, _threeImageView.bottom-120,//控制点
                                  _threeImageView.right-150, _threeImageView.bottom-250,//控制点
                                  _threeImageView.right-(100+(i*55)), _threeImageView.bottom-(290-(i*55)));//控制点
            CGPathAddCurveToPoint(<#CGMutablePathRef path#>, <#const CGAffineTransform *m#>, <#CGFloat cp1x#>, <#CGFloat cp1y#>, <#CGFloat cp2x#>, <#CGFloat cp2y#>, <#CGFloat x#>, <#CGFloat y#>)
            customButton.center=CGPointMake(_threeImageView.right-(100+(i*55)), _threeImageView.bottom-(290-(i*55)));
            //            iconImageView.frame=customButton.frame;
            
            
        } else if (i == 2) {
            CGPathAddCurveToPoint(aPath, nil,
                                  _threeImageView.right-280, _threeImageView.bottom-120,//控制点
                                  _threeImageView.right-150, _threeImageView.bottom-250,//控制点
                                  _threeImageView.left+(1*i),_threeImageView.bottom-(280-60*i));//控制点
            customButton.center=CGPointMake(_threeImageView.left+(1*i), _threeImageView.bottom-(280-60*i));
            
        } else if (i==3) {
            CGPathAddCurveToPoint(aPath, nil,
                                  _threeImageView.right-280, _threeImageView.bottom-120,//控制点
                                  _threeImageView.right-150, _threeImageView.bottom-250,//控制点
                                  _threeImageView.left+(5*i),_threeImageView.bottom-(25*i));//控制点
            
            
            customButton.center=CGPointMake(_threeImageView.left+(5*i), _threeImageView.bottom-(25*i));
            
        } else if (i==4) {
            CGPathAddCurveToPoint(aPath, nil,
                                  _threeImageView.right-280, _threeImageView.bottom-120,//控制点
                                  _threeImageView.right-150, _threeImageView.bottom-250,//控制点
                                  _threeImageView.left+(18*i),_threeImageView.bottom-(5*i));//控制点
            customButton.center=CGPointMake(_threeImageView.left+(18*i), _threeImageView.bottom-(5*i));
            
        }
        
        
        ani.path=aPath;
        ani.duration=2;
        //设置为渐出
        ani.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
        //自动旋转方向
        //        ani.rotationMode=@"auto";
        
        ani.removedOnCompletion = NO;
        ani.fillMode = kCAFillModeForwards;
        //
        [customButton.layer addAnimation:ani forKey:@"position"];
        
    }
    
    [self performSelector:@selector(createView) withObject:nil afterDelay:1.5];
}

- (void)buttonClick:(UIButton *)button
{
    
    if (button.tag-2014 == 0) {
        ListViewController *temp = [[ListViewController alloc] init];
        [self.navigationController pushViewController:temp animated:YES];
        [temp release];
    }
    if (button.tag-2014 == 1) {
        MoreViewController *temp = [[MoreViewController alloc] init];
        [self.navigationController pushViewController:temp animated:YES];
        [temp release];
    }
    if (button.tag-2014 == 2) {
        WorkViewController *work = [[WorkViewController alloc] init];
        [self.navigationController pushViewController:work animated:YES];
        [work release];
    }
    if (button.tag - 2014 == 3) {
        ActivityViewController *activity = [[ActivityViewController alloc] init];
        [self.navigationController pushViewController:activity animated:YES];
        [activity release];
    }
    if (button.tag-2014 == 4) {
        WeeklyViewController *week = [[WeeklyViewController alloc] init];
        [self.navigationController pushViewController:week animated:YES];
        [week release];
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
