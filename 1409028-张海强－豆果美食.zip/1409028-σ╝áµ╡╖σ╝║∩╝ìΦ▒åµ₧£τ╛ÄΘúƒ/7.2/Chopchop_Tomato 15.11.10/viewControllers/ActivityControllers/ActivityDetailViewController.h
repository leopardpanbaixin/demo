//
//  ActivityDetailViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActivityDetailViewController : UIViewController {
    UIWebView *_webView;
}
@property (nonatomic,copy) NSString *urlStr;
@end
