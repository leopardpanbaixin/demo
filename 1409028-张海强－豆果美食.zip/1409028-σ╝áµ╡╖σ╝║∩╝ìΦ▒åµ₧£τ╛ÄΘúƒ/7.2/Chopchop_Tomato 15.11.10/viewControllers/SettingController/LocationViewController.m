//
//  LocationViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-27.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "LocationViewController.h"
#import "RootViewController.h"

@interface LocationViewController ()

@end

@implementation LocationViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataArray = [[NSMutableArray alloc] init];
    [self createNav];
    [self createTableView];
    [self loadData];
}

- (void)loadData
{
    _request = [[ASIFormDataRequest alloc] initWithURL:[NSURL URLWithString:SUPPORTCITY_URL]];
    NSString *strUrl = @"2013-07-09+01%3A40%3A01";
    strUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [_request setPostValue:strUrl forKey:@"latesttime"];
    _request.delegate = self;
    
    //    开始异步上传
    [_request startAsynchronous];
}
- (void)requestFinished:(ASIHTTPRequest *)request
{

    id result = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:nil];
    if ([result isKindOfClass:[NSDictionary class]]) {
        NSDictionary *dataDic = (NSDictionary *)result;
       self.dataArray = [dataDic objectForKey:@"supportcity"];
        
        [_tableView reloadData];
    }
}
- (void)createTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0,  0, ScreenWidth, ScreenHeight - [MyControl isIOS7])];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    [self.view addSubview:_tableView];
    [_tableView release];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataArray.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.dataArray[section]objectForKey:@"citylist"] count];

}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"id"];
    }
    self.id = [[[self.dataArray[indexPath.section] objectForKey:@"citylist"] objectAtIndex:indexPath.row] objectForKey:@"id"];
    self.city = [[[self.dataArray[indexPath.section] objectForKey:@"citylist"] objectAtIndex:indexPath.row] objectForKey:@"city"];
    cell.textLabel.text = [[[self.dataArray[indexPath.section] objectForKey:@"citylist"] objectAtIndex:indexPath.row] objectForKey:@"city"];
   
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 38;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 300, 34)];
    label.backgroundColor = [UIColor darkGrayColor];
    label.text = [NSString stringWithFormat:@"    %@",[self.dataArray[section] objectForKey:@"cityclassify"]];
    return label;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}
- (void)createNav
{
    self.navigationController.navigationBar.translucent = NO;
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"juchi.png"] forBarMetrics:UIBarMetricsDefault];
    
    self.navigationItem.title = @"城市选择";
    [self createNavButton];
}

- (void)createNavButton
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
}

- (void)leftButtonClick
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
