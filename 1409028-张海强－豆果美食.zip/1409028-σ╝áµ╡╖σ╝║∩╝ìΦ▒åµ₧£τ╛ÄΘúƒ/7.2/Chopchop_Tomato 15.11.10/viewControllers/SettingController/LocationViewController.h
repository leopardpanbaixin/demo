//
//  LocationViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-27.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"

@interface LocationViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,ASIHTTPRequestDelegate> {
    
    UITableView *_tableView;
    ASIFormDataRequest *_request;

}

@property (nonatomic,retain) NSMutableArray *dataArray;
@property (nonatomic,retain) NSNumber *id;
@property (nonatomic,copy) NSString *city;

@end
