//
//  ButtonViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ButtonViewController.h"
#import "ButtonModel.h"
#import "ButtonCell.h"
#import "DetailCatViewController.h"

@interface ButtonViewController ()

@end

@implementation ButtonViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.dataArray = [[NSMutableArray alloc] init];
    self.dataDict = [[NSMutableDictionary alloc] init];
	[self createNav];
    [self createTextField];
    [self createTableView];
    [self loadData];
    [(UIScrollView *)_tableView setBounces:NO];
}
-(void)createNav
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
    
}

-(void)leftButtonClick
{
    [_textField resignFirstResponder];
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)createTextField
{
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 200, 40)];

    UILabel *label = [MyControl createLabelWithFrame:CGRectMake(0, 5, 200, 16) Font:14 Text:self.text];
    [view addSubview:label];
    UIImageView *_imageView = [MyControl createImageViewFrame:CGRectMake(0, label.bottom, 200, 10) imageName:@"searchBar"];
    [view addSubview:_imageView];
    self.navigationItem.titleView = view;

}

-(void)createTableView
{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-[MyControl isIOS7]) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    [_tableView release];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ButtonCell *cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil){
        cell=[[[ButtonCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"]autorelease];
    }
  
    ButtonModel *model=[self.dataArray objectAtIndex:indexPath.row];
    [cell config:model];
    return cell;
}
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DetailCatViewController *detail = [[DetailCatViewController alloc] init];
    ButtonModel *model = self.dataArray[indexPath.row];
    detail.buttonModel = model;
    [self.navigationController pushViewController:detail animated:YES];
    [detail release];
}
-(void)loadData
{
    _request=[[HttpPostRequest alloc]init];

    NSString *str=[self.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"4",@"client",self.sign_ran,@"sign_ran",str,@"keyword",self.code,@"code",nil];
      _request.delegate = self;
    [_request downloadDataWithUrlString:@"http://api.douguo.net/recipe/search/0/15" requestMethod:@"POST" contentType:@"application/x-www-form-urlencoded" paraDic:dic];
  
}
-(void)httpRequestFailed:(HttpPostRequest *)request
{

}
-(void)httpRequestFinished:(HttpPostRequest *)request
{
    
 
    if (request.downloadData) {
        id result = [NSJSONSerialization JSONObjectWithData:request.downloadData options:NSJSONReadingMutableContainers error:nil];
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dataDic = (NSDictionary *)result;
            NSArray *array = [[dataDic objectForKey:@"result"] objectForKey:@"recipes"];
         
            for (NSDictionary *dataDic in array) {
                ButtonModel *model = [[ButtonModel alloc] init];
                [model setValuesForKeysWithDictionary:dataDic];
                [self.dataArray addObject:model];
                [model release];
            }
                  [_tableView reloadData];
            
        }
    }


    
 
}

-(void)viewWillDisappear:(BOOL)animated
{
    imageView.hidden=YES;
    _textField.hidden=YES;
}
-(void)viewWillAppear:(BOOL)animated
{
    imageView.hidden=YES;
    _textField.hidden=YES;
}
-(void)viewDidAppear:(BOOL)animated
{
    imageView.hidden=NO;
    _textField.hidden=NO;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
