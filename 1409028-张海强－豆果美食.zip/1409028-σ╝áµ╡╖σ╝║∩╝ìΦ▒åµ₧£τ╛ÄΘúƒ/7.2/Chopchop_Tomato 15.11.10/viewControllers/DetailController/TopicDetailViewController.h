//
//  TopicDetailViewController.h
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-7-6.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpPostRequest.h"

@interface TopicDetailViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,HttpRequestDelegate> {
    UITableView *_tableView1;
    UITableView *_tableView2;
    HttpPostRequest *_request;
}

@property (nonatomic,copy) NSString *sign_ran;
@property (nonatomic,copy) NSString *code;

@property (nonatomic,retain) NSMutableArray *dataArray1;
@property (nonatomic,retain) NSMutableArray *dataArray2;

@end
