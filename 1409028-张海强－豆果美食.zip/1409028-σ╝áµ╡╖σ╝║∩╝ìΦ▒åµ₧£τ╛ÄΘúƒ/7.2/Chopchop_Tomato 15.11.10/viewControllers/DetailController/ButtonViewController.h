//
//  ButtonViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpPostRequest.h"

@interface ButtonViewController : UIViewController<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,HttpRequestDelegate>
{
    UITextField *_textField;
    UITableView *_tableView;
    HttpPostRequest *_request;
    UIImageView *imageView;
}
@property(nonatomic,retain)NSMutableArray *dataArray;
@property(nonatomic,retain)NSMutableDictionary *dataDict;
@property(nonatomic,copy)NSString *text;
@property (nonatomic,copy) NSString *sign_ran;
@property (nonatomic,copy) NSString *code;

@end
