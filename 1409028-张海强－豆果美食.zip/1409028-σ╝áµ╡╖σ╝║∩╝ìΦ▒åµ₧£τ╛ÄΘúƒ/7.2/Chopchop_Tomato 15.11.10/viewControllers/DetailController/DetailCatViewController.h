//
//  DetailCatViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-4.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ButtonModel.h"

@interface DetailCatViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
{
    UIScrollView *_backgroundScrollView;
    UILabel *_zlLabel;
    UILabel *_flLabel;
    NSDictionary *_dic;
    UITableView *_tableView;
    UILabel *_xtLabel;
}
@property (nonatomic,retain) ButtonModel *buttonModel;

@end
