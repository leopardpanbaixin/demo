//
//  MoreViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpPostRequest.h"
@interface MoreViewController : UIViewController<UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource,HttpRequestDelegate>
{
    UITableView *_tableView1;
    
    UITableView *_tableView2;
    HttpPostRequest *_request;
}

@property(nonatomic,retain)NSMutableDictionary *dataDict;
@property(nonatomic,retain)NSMutableArray *dataArray1;
@property(nonatomic,retain)NSMutableArray *dataArray2;

@end
