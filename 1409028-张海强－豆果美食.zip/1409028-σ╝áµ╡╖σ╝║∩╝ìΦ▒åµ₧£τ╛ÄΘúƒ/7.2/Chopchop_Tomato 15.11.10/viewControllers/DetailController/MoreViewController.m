//
//  MoreViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "MoreViewController.h"
#import "MoreModel.h"
#import "UIImageView+WebCache.h"
@interface MoreViewController ()

@end

@implementation MoreViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createNav];
    [self createTableView1];
    [self createTableView2];
    [self loadData];
}
- (void)createNav
{
    self.navigationController.navigationBar.translucent = NO;
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"juchi.png"] forBarMetrics:UIBarMetricsDefault];
    
    self.navigationItem.title = @"豆果";
    [self createNavButton];
}

- (void)createNavButton
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
}

- (void)leftButtonClick
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)createTableView1
{
    _tableView1=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 100, self.view.frame.size.height-[MyControl isIOS7]) style:UITableViewStylePlain];
    _tableView1.delegate=self;
    _tableView1.dataSource=self;
    _tableView1.bounces=NO;
    _tableView1.showsHorizontalScrollIndicator=NO;
    _tableView1.showsVerticalScrollIndicator=NO;
    [self.view addSubview:_tableView1];
    [_tableView1 release];
    
}

-(void)createTableView2
{
    _tableView2=[[UITableView alloc]initWithFrame:CGRectMake(100, 0, 240, self.view.frame.size.height) style:UITableViewStylePlain];
    _tableView2.delegate=self;
    _tableView2.dataSource=self;
    _tableView2.separatorStyle=0;
    _tableView2.bounces=NO;
    [self.view addSubview:_tableView2];
    [_tableView2 release];
 
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView==_tableView1){
        return self.dataArray1.count;
    }else
    {
        return self.dataArray2.count/6;
    }
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"is"];
    if (cell==nil){
        cell=[[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"is"]autorelease];
    }
    
    if (tableView==_tableView1){
        
        MoreModel *model=[self.dataArray1 objectAtIndex:indexPath.row];
        [self.dataArray2 addObjectsFromArray:model.tags];
        UIImageView *imageView=[MyControl createImageViewFrame:CGRectMake(30, 30, 40, 40) imageName:nil];
        [imageView setImageWithURL:[NSURL URLWithString:model.icon] placeholderImage:[UIImage imageNamed:@"top_add_del_btn_bg_dis@2x"]];
        cell.contentView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"top_add_del_btn_bg_dis@2x"]];
        [cell.contentView addSubview:imageView];
        
    }
    
    if (tableView==_tableView2)
    {

        NSMutableArray *array=[NSMutableArray arrayWithCapacity:0];
        for (NSDictionary *dic in self.dataArray2) {
            [array addObject:[dic objectForKey:@"t"]];
        }
      
        cell.contentView.tag=indexPath.row;
            for (int i=0;i<6;i++){
            UIButton *button=[MyControl createButtonWithFrame:CGRectMake(10+i%3*70, 6+i/3*36, 60, 30) target:self SEL:@selector(buttonClick:) title:array[i+6*indexPath.row] imageName:nil bgImageName:nil];
                button.font=[UIFont systemFontOfSize:12];
                [button setBackgroundImage:[UIImage imageNamed:@"cm_view_bgimg@2x"] forState:UIControlStateNormal];
                [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [[cell.contentView viewWithTag:indexPath.row]addSubview:button];
          
            button.tag=100+i;
        }
        
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.dataArray2=[NSMutableArray arrayWithCapacity:0];
    if (tableView==_tableView1){
        MoreModel *model=[self.dataArray1 objectAtIndex:indexPath.row];
        [self.dataArray2 addObjectsFromArray:model.tags];
        [_tableView2 reloadData];
        NSLog(@"%s",__FUNCTION__);
    }
}

-(void)buttonClick:(UIButton *)button
{
      NSLog(@"%s",__FUNCTION__);
}

-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView==_tableView1){
        return 100;
    }else{
        return 80;
    }
}

-(void)loadData
{
  //  NSString *str=[self.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"4",@"client",@"4f3150b3bc9dc4e5615abdf5c70927f2",@"sign_ran",@"0c786f2c8469ceb6",@"code",nil];
    _request=[[HttpPostRequest alloc]init];
    [_request asiDownloadWithUrlString:@"http://api.douguo.net/recipe/flatcatalogs" requestMethod:@"POST" paraDic:dic];
    _request.delegate = self;
    
}
-(void)httpRequestFinished:(HttpPostRequest *)request
{
    
    self.dataArray1=[NSMutableArray arrayWithCapacity:0];
    self.dataArray2 = [[NSMutableArray alloc] init];
    self.dataDict=[NSMutableDictionary dictionaryWithCapacity:0];
    NSLog(@"请求完成%@",request.downloadData);
    if (request.downloadData){
        id result=[NSJSONSerialization JSONObjectWithData:request.downloadData options:NSJSONReadingMutableContainers error:nil];
        
        if ([result isKindOfClass:[NSDictionary class]]){
            self.dataDict=result;
            NSArray *array=[[self.dataDict objectForKey:@"result"]objectForKey:@"catalogs"];
            for (NSDictionary *dic1 in array) {
                MoreModel *model=[[MoreModel alloc]init];
                [model setValuesForKeysWithDictionary:dic1];
   
                [self.dataArray1 addObject:model];
                [model release];
            }
         
            [_tableView1 reloadData];
            if ([self.dataArray1 count] > 0) {
                NSLog(@"wocao");
                MoreModel *model=[self.dataArray1 objectAtIndex:0];
                [self.dataArray2 addObjectsFromArray:model.tags];
                NSLog(@"\n\n\n %@",model.tags);
                [_tableView2 reloadData];
            }
        }
    }
    NSLog(@"%@",self.dataArray1);
   
}
- (void)httpRequestFailed:(HttpPostRequest *)request
{
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
