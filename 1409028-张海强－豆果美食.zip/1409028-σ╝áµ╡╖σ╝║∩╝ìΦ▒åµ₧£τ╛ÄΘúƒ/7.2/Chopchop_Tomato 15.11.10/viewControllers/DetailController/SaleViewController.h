//
//  SaleViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpPostRequest.h"
#import "PullTableView.h"

@interface SaleViewController : UIViewController <HttpRequestDelegate,PullTableViewDelegate,UITableViewDataSource,UITableViewDelegate> {
    HttpPostRequest *_request;
    PullTableView *_pullTableView;
}

@property (nonatomic,retain) NSMutableArray *dataArray;
@property (nonatomic,retain) NSMutableArray *detailArray;

@end
