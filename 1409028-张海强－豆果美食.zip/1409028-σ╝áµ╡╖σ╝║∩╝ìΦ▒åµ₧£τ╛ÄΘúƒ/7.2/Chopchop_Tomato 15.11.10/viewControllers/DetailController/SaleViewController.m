//
//  SaleViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "SaleViewController.h"
#import "DetailModel.h"
#import "DetailCell.h"
#import "UIImageView+WebCache.h"

@interface SaleViewController ()

@end

@implementation SaleViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataArray = [[NSMutableArray alloc] init];
    self.detailArray = [[NSMutableArray alloc] init];
    [self createNav];
    [self createTableView];
    [self loadData];
}
#pragma mark 获得数据
- (void)loadData
{
    _request = [[HttpPostRequest alloc]init];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"4",@"client",@"3e6d93699337a1137b6ab2b2961f0090",@"sign_ran",@"358cf34a1d2319ff",@"code",nil];
    
    [_request asiDownloadWithUrlString:@"http://api.douguo.net/recipe/mallheadline/" requestMethod:@"POST" paraDic:dic];
    _request.delegate = self;
}
- (void) httpRequestFinished:(HttpPostRequest *)request
{
    
    if (request.downloadData) {
        id result = [NSJSONSerialization JSONObjectWithData:request.downloadData options:NSJSONReadingMutableContainers error:nil];
      
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dataDic = (NSDictionary *)result;
            NSArray *array = [[dataDic objectForKey:@"result"] objectForKey:@"headline"];
       
            for (NSDictionary *dic in array) {
                
                NSDictionary *dataDic = [dic objectForKey:@"content"];
                DetailModel *model1 = [[DetailModel alloc] init];
                [model1 setValuesForKeysWithDictionary:dataDic];
                [self.detailArray addObject:model1];
            }
            [_pullTableView reloadData];
        }
    }
}

- (void) httpRequestFailed:(HttpPostRequest *)request
{
    
}

#pragma mark 创建tableView
- (void)createTableView
{
    _pullTableView = [[PullTableView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight - [MyControl isIOS7]) style:UITableViewStylePlain];
    _pullTableView.pullDelegate = self;
    _pullTableView.delegate = self;
    _pullTableView.dataSource = self;
    _pullTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _pullTableView.pullArrowImage = [UIImage imageNamed:@"blackArrow"];
    _pullTableView.pullBackgroundColor = [UIColor whiteColor];
    _pullTableView.pullTextColor = [UIColor blackColor];
    [self.view addSubview:_pullTableView];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 190;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  
    DetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CEID"];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"DetailCell" owner:self options:nil] lastObject];
    }
    DetailModel *detail = self.detailArray[indexPath.row];
    [cell.saleImageView setImageWithURL:[NSURL URLWithString:detail.thb]];
    cell.timeLabel.text = detail.et;
    cell.titleLabel.text = detail.t;
    cell.detLabel.text = detail.rr;
    cell.curLabel.text = [NSString stringWithFormat:@"￥%@",detail.p];
    cell.oldLabel.text = detail.op;
    cell.disLabel.text = [detail.st stringValue];
    cell.perLabel.text = [NSString stringWithFormat:@"%@人已抢",[detail.sc stringValue]];
    return cell;
}

#pragma mark pullDelegate的代理
- (void)pullTableViewDidTriggerRefresh:(PullTableView *)pullTableView{
    NSLog(@"pull to refresh...");
    [self performSelector:@selector(refreshTable) withObject:nil afterDelay:1.0f];
}
- (void)pullTableViewDidTriggerLoadMore:(PullTableView *)pullTableView{
    NSLog(@"pull to loadmore...");
    [self performSelector:@selector(loadMoreDataToTable) withObject:nil afterDelay:1.0f];
}
- (void)refreshTable{
    _pullTableView.pullTableIsRefreshing = NO;
    _pullTableView.pullLastRefreshDate = [NSDate date];

    [self loadData];
}
- (void)loadMoreDataToTable{
    _pullTableView.pullTableIsLoadingMore = NO;
    
    [self loadData];
}

#pragma mark 导航
- (void)createNav
{
    self.navigationController.navigationBar.translucent = NO;
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"juchi.png"] forBarMetrics:UIBarMetricsDefault];
    
    [self createNavButton];
}

- (void)createNavButton
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
}

- (void)leftButtonClick
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
