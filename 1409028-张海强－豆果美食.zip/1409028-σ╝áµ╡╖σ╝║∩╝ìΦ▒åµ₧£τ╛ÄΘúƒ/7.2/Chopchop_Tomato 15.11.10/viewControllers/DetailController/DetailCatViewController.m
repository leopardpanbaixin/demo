//
//  DetailCatViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-4.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "DetailCatViewController.h"
#import "UIButton+WebCache.h"
#import "UIImageView+WebCache.h"
#import "StepCell.h"

@interface DetailCatViewController ()

@end

@implementation DetailCatViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createNav];
    [self createBackground];
}
- (void)createBackground
{
    self.view.backgroundColor = [UIColor colorWithRed:224/256.0 green:215/256.0 blue:194/256.0 alpha:1];
    _backgroundScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight - [MyControl isIOS7])];
 
    _backgroundScrollView.contentSize = CGSizeMake(ScreenWidth, ScreenHeight+400+self.buttonModel.cookstep.count*120);
    
    [_backgroundScrollView setBounces:NO];
    [self.view addSubview:_backgroundScrollView];
    
    [self configUI];
}
#pragma mark 布局UI
- (void)configUI
{
    UIImageView *simageView = [MyControl createImageViewFrame:CGRectMake(0, 0, ScreenWidth, 240) imageName:nil];
    [simageView setImageWithURL:[NSURL URLWithString:self.buttonModel.photo_path]];
    [_backgroundScrollView addSubview:simageView];
//-------------------------------
    UIImageView *aimageView = [MyControl createImageViewFrame:CGRectMake(20, simageView.bottom - 30, 60, 60) imageName:nil];
    [aimageView setImageWithURL:[NSURL URLWithString:self.buttonModel.author_photo]];
    aimageView.layer.cornerRadius = 30;
    aimageView.layer.masksToBounds = YES;
    [_backgroundScrollView addSubview:aimageView];
    
    UILabel *nameLabel = [MyControl createLabelWithFrame:CGRectMake(aimageView.right + 5, simageView.bottom - 20, 100, 20) Font:16 Text:nil];
    nameLabel.textColor = [UIColor whiteColor];
    nameLabel.text = self.buttonModel.author;
    [_backgroundScrollView addSubview:nameLabel];
//----------------------------------
    UILabel *titleLabel = [MyControl createLabelWithFrame:CGRectMake(20, aimageView.bottom + 10, 160, 30) Font:20 Text:nil];
    titleLabel.text = self.buttonModel.title;
    [_backgroundScrollView addSubview:titleLabel];
//    ------------------------------
    UILabel *countLabel =[MyControl createLabelWithFrame:CGRectMake(20, titleLabel.bottom + 5, 30, 20) Font:16 Text:nil];
    countLabel.textColor = [UIColor brownColor];
    countLabel.text = [self.buttonModel.favo_counts stringValue];
    [_backgroundScrollView addSubview:countLabel];
    
    UILabel *countLabel1 =[MyControl createLabelWithFrame:CGRectMake(countLabel.right + 50, titleLabel.bottom + 5, 30, 20) Font:16 Text:nil];
    countLabel1.textColor = [UIColor brownColor];
    countLabel1.text = [self.buttonModel.dish_count stringValue];
    [_backgroundScrollView addSubview:countLabel1];
    
    UILabel *nLabel = [MyControl createLabelWithFrame:CGRectMake(countLabel.right, titleLabel.bottom+5, 40, 20) Font:12 Text:@"收藏"];
    nLabel.textColor = [UIColor grayColor];
    [_backgroundScrollView addSubview:nLabel];
    
    UILabel *nLabel1 = [MyControl createLabelWithFrame:CGRectMake(countLabel1.right, titleLabel.bottom+5, 40, 20) Font:12 Text:@"评论"];
    nLabel1.textColor = [UIColor grayColor];
    [_backgroundScrollView addSubview:nLabel1];
    
//    --------------------------------
    UIButton *favoButton = [MyControl createButtonWithFrame:CGRectMake(20, nLabel.bottom+20, 130, 30) target:self SEL:@selector(favoButtonClick) title:@"收藏菜谱" imageName:nil bgImageName:nil];
    favoButton.backgroundColor = [UIColor brownColor];
    [_backgroundScrollView addSubview:favoButton];
    
    UIButton *shopButton = [MyControl createButtonWithFrame:CGRectMake(favoButton.right+10, nLabel.bottom+20, 130, 30) target:self SEL:@selector(favoButtonClick) title:@"加入购物单" imageName:nil bgImageName:nil];
    shopButton.backgroundColor = [UIColor brownColor];
    [_backgroundScrollView addSubview:shopButton];
    
//    --------------------------------
    UILabel *zLabel = [MyControl createLabelWithFrame:CGRectMake(20, shopButton.bottom+10, 200, 30) Font:16 Text:@"主料"];
    zLabel.textColor = [UIColor brownColor];
    [_backgroundScrollView addSubview:zLabel];
    
//    ---------------------------------
    if (self.buttonModel.major.count>0) {
        for (int i=0; i<self.buttonModel.major.count; i++) {
            NSDictionary *dic = self.buttonModel.major[i];
            NSString *note = [dic objectForKey:@"note"];
            NSString *title = [dic objectForKey:@"title"];
            _zlLabel = [MyControl createLabelWithFrame:CGRectMake(20, zLabel.bottom+5+(31*i), 280, 30) Font:14 Text:nil];
            _zlLabel.backgroundColor = [UIColor whiteColor];
            _zlLabel.text = [NSString stringWithFormat:@"%@                                            %@",title,note];
            [_backgroundScrollView addSubview:_zlLabel];
        }
    }
//    --------------------------------
    UILabel *flLabel = [MyControl createLabelWithFrame:CGRectMake(20, _zlLabel.bottom+5, 200, 30) Font:16 Text:@"辅料"];
    [_backgroundScrollView addSubview:flLabel];
    
    
// ------------------------------------------------------------

    if (self.buttonModel.minor.count>0) {
        if (self.buttonModel.minor.count%2==0) {
            for (int i=0; i<self.buttonModel.minor.count/2; i++) {
                for (int j=0; j<2; j++) {
                    _dic = self.buttonModel.minor[i*2+j];
                    NSString *note = [_dic objectForKey:@"note"];
                    NSString *title = [_dic objectForKey:@"title"];
                    _flLabel = [MyControl createLabelWithFrame:CGRectMake(20+(j%2)*140, flLabel.bottom+5, 139, 30) Font:14 Text:nil];
                    _flLabel.backgroundColor = [UIColor whiteColor];
                    _flLabel.text = [NSString stringWithFormat:@"%@             %@",title,note];
                    [_backgroundScrollView addSubview:_flLabel];
                }
            }
        } else if (self.buttonModel.minor.count%2==1) {
            for (int i=0; i<self.buttonModel.minor.count/2+1; i++) {
                for (int j=0; j<2; j++) {
                   
                    _flLabel = [MyControl createLabelWithFrame:CGRectMake(20+(j%2)*140, flLabel.bottom+5, 139, 30) Font:14 Text:nil];
                    _flLabel.backgroundColor = [UIColor whiteColor];
                    [_backgroundScrollView addSubview:_flLabel];
                    
                    if (2*i+j == self.buttonModel.minor.count) {
                        _flLabel.text = @"";
                    } else {
                        _dic = self.buttonModel.minor[i*2+j];
                        NSString *note = [_dic objectForKey:@"note"];
                        NSString *title = [_dic objectForKey:@"title"];
                        _flLabel.text = [NSString stringWithFormat:@"%@             %@",title,note];
                    }
                    
                }
            }
        }
    }
    
//    --------------制作步骤---------------------
    UILabel *zzLabel = [MyControl createLabelWithFrame:CGRectMake(20, flLabel.bottom+10+(self.buttonModel.minor.count*30)/2, 150, 40) Font:22 Text:@"制作步骤"];
    zzLabel.textColor = [UIColor brownColor];
    [_backgroundScrollView addSubview:zzLabel];
    
    UILabel *cfLabel = [MyControl createLabelWithFrame:CGRectMake(zzLabel.right, flLabel.bottom+(((self.buttonModel.minor.count%2)+self.buttonModel.minor.count)*30)/2, 130, 40) Font:12 Text:@"点击步骤进入厨房模式"];
    cfLabel.textColor = [UIColor grayColor];
    [_backgroundScrollView addSubview:cfLabel];
    
//    ---------------------------------------
    if (self.buttonModel.cookstep.count>0) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, cfLabel.bottom+5, ScreenWidth, 120*self.buttonModel.cookstep.count) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_backgroundScrollView addSubview:_tableView];
        [(UIScrollView *)_tableView setBounces:YES];
    }
    
//    --------进入小贴士-----------------
    UILabel *xtLabel = [MyControl createLabelWithFrame:CGRectMake(20, _tableView.bottom+10, 200, 40) Font:24 Text:@"小贴士"];
    xtLabel.textColor = [UIColor brownColor];
    [_backgroundScrollView addSubview:xtLabel];
    
//    ---------------小贴士------------------------------
    
    if (self.buttonModel.tips) {
        NSString *tips = self.buttonModel.tips;
       CGSize size = [tips sizeWithFont:[UIFont systemFontOfSize:12] constrainedToSize:CGSizeMake(ScreenWidth, 300)];
        _xtLabel = [MyControl createLabelWithFrame:CGRectMake(20, xtLabel.bottom+5, 280, size.height) Font:12 Text:nil];
        _xtLabel.text = tips;
        [_backgroundScrollView addSubview:_xtLabel];
    }
//    --------------图像-------------------
//    UILabel *djLabel = [MyControl createLabelWithFrame:CGRectMake(20, _xtLabel.bottom, 200, 40) Font:24 Text:@"大家做的这道菜"];
//    djLabel.textColor = [UIColor brownColor];
//    [_backgroundScrollView addSubview:djLabel];
//    -----------------------------------------
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.buttonModel.cookstep.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    StepCell *cell = [tableView dequeueReusableCellWithIdentifier:@"stepid"];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"StepCell" owner:self options:nil] lastObject];
    }
    NSDictionary *dic = self.buttonModel.cookstep[indexPath.row];
    NSString *content = [NSString stringWithFormat:@"%d.%@",indexPath.row+1,[dic objectForKey:@"content"]];
    NSString *thumb = [dic objectForKey:@"thumb"];
    
    cell.detailLabel.text = content;
    [cell.stepImageView setImageWithURL:[NSURL URLWithString:thumb]];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}
- (void)favoButtonClick
{
    
}
#pragma mark 创建导航
- (void)createNav
{
    self.navigationController.navigationBar.translucent = NO;
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"juchi.png"] forBarMetrics:UIBarMetricsDefault];
    
    self.navigationItem.title = self.buttonModel.title;
    [self createNavButton];
}

- (void)createNavButton
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
}

- (void)leftButtonClick
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
