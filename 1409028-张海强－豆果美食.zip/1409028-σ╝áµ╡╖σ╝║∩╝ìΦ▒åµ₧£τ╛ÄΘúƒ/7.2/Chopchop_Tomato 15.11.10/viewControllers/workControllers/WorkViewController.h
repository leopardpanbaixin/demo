//
//  WorkViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpPostRequest.h"
#import "PullTableView.h"
#import "WorkModel.h"

@interface WorkViewController : UIViewController <HttpRequestDelegate,UITableViewDataSource,UITableViewDelegate,PullTableViewDelegate> {
    PullTableView *_tableView;
    HttpPostRequest *_request;
    int _page;
    WorkModel *_model;
    UIView *_shareView;
}

@property (nonatomic,retain) NSMutableArray *dataArray;
@property (nonatomic,retain) NSMutableArray *userArray;

@end
