//
//  WorkViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "WorkViewController.h"
#import "WorkCell.h"
#import "UserWorkModel.h"
#import "UIButton+WebCache.h"
#import "UIImageView+WebCache.h"
#import "WeeklyViewController.h"
#import "UMSocial.h"
#import "PersonViewController.h"
#import "WorkDetailViewController.h"

@interface WorkViewController ()

@end

@implementation WorkViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _userArray = [[NSMutableArray alloc] init];
    _dataArray = [[NSMutableArray alloc] init];
    _page = 1;
    [self createNav];
    [self createTableView];
    [self loadData];
}
#pragma mark loadData
- (void)loadData
{
    _request = [[HttpPostRequest alloc] init];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"4",@"client",@"ac930e3a401acdb845d866ea6550f666",@"sign_ran",@"a000eb3d04349f46",@"code",nil];
    
    [_request asiDownloadWithUrlString:@"http://api.douguo.net/recipe/topdishes/0/15/0" requestMethod:@"POST" paraDic:dic];
    _request.delegate = self;
}
- (void) httpRequestFinished:(HttpPostRequest *)request
{
    
    if (request.downloadData) {
        id result = [NSJSONSerialization JSONObjectWithData:request.downloadData options:NSJSONReadingMutableContainers error:nil];
        if (_page == 1) {
            [self.dataArray removeAllObjects];
        }
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dataDic = (NSDictionary *)result;
            NSArray *array = [[dataDic objectForKey:@"result"] objectForKey:@"dishes"];
//            NSLog(@"-----------------%@",array);
            for (NSDictionary *dic in array) {
                
                NSDictionary *dict1 = [dic objectForKey:@"dish"];
                
                _model=[[WorkModel alloc]init];
                [_model setValuesForKeysWithDictionary:dict1];
                [self.dataArray addObject:_model];
                NSDictionary*aa=[dict1 objectForKey:@"author"];
                
                UserWorkModel*mode1=[[UserWorkModel alloc]init];
                [mode1 setValuesForKeysWithDictionary:aa];
                [self.userArray addObject:mode1];
                
                
//                [dict1 enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
//                    
//                    NSDictionary *dictr1 = [NSDictionary dictionaryWithObject:obj forKey:key];
//                    WorkModel *model = [[WorkModel alloc] init];
//                    [model setValuesForKeysWithDictionary:dictr1];
//                    [self.dataArray addObject:model];
//                    
//                    
//                }];
//                
//                NSDictionary *dicti = [dict1 objectForKey:@"author"];
//                [dicti enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
//                    NSDictionary *dicti1 = [NSDictionary dictionaryWithObject:obj forKey:key];
//                    UserWorkModel *model = [[UserWorkModel alloc] init];
//                    [model setValuesForKeysWithDictionary:dicti1];
//                    [self.userArray addObject:model];
//                }];
//                for (NSString *key in [dicti allKeys]) {
//                    NSString *value = [NSString stringWithFormat:@"%@",[dicti objectForKey:key]];
//                    UserWorkModel *model = [[UserWorkModel alloc] init];
//                    
//                    [model setValue:value forKey:key];
//                    [self.userArray addObject:model];
//                    [model release];
//                }
            }
            [_tableView reloadData];
        }
    }
}

- (void) httpRequestFailed:(HttpPostRequest *)request
{
    
}

#pragma mark createTableView
- (void)createTableView
{
    _tableView = [[PullTableView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.pullDelegate = self;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.pullArrowImage = [UIImage imageNamed:@"blackArrow"];
    _tableView.pullBackgroundColor = [UIColor whiteColor];
    _tableView.pullTextColor = [UIColor blackColor];
    [self.view addSubview:_tableView];
    [_tableView release];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 255;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    WorkCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
    if (cell == nil) {
        cell = [[[WorkCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellID"] autorelease];
        cell.backgroundColor = [UIColor colorWithRed:224/256.0 green:215/256.0 blue:194/256.0 alpha:0.6];
        
    }
    
    UserWorkModel *workModel = self.userArray[indexPath.row];
    [cell configUserModel:workModel];
    _model = self.dataArray[indexPath.row];
    [cell configModel:_model];
    for (int i=2014; i<2017; i++) {
        UIControl *control = (UIControl *)[cell.contentView viewWithTag:i];
        [control removeTarget:self action:@selector(cellButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [control addTarget:self action:@selector(cellButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    UIControl *control = (UIControl *)[cell.contentView viewWithTag:2013];
    [control removeTarget:self action:@selector(cellButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [control addTarget:self action:@selector(cellButtonAction) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}
- (void)cellButtonAction
{
    WeeklyViewController *week = [[WeeklyViewController alloc] init];
    [self.navigationController pushViewController:week animated:YES];
}
- (void)cellButtonClick:(UIControl *)control
{
    if (control.tag == 2014) {
       
                [UMSocialSnsService presentSnsIconSheetView:self appKey:@"53ae1ed356240b4569096" shareText:[NSString stringWithFormat:@"[%@],这个作品我喜欢",_model.cook_title] shareImage:nil shareToSnsNames:@[UMShareToSina,UMShareToQzone,UMShareToTencent,UMShareToEmail,UMShareToSms,UMShareToTwitter,UMShareToDouban,UMShareToRenren] delegate:nil];
        
        
    }
    if (control.tag == 2015) {
        WeeklyViewController *week = [[WeeklyViewController alloc] init];
        [self.navigationController pushViewController:week animated:YES];
    }
    if (control.tag == 2016) {
        PersonViewController *person = [[PersonViewController alloc] init];
        [self.navigationController pushViewController:person animated:YES];
        [person release];
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    WorkDetailViewController *detail = [[WorkDetailViewController alloc] init];
   WorkModel *work = self.dataArray[indexPath.row];
    UserWorkModel * user = self.userArray[indexPath.row];
    detail.dish_id = work.dish_id;
    detail.cook_title = work.cook_title;
    detail.workModel = work;
    detail.userModel = user;
    [self.navigationController pushViewController:detail animated:YES];
    [detail release];
}

- (void)pullTableViewDidTriggerRefresh:(PullTableView *)pullTableView{
    NSLog(@"pull to refresh...");
    [self performSelector:@selector(refreshTable) withObject:nil afterDelay:1.0f];
}
- (void)pullTableViewDidTriggerLoadMore:(PullTableView *)pullTableView{
    NSLog(@"pull to loadmore...");
    [self performSelector:@selector(loadMoreDataToTable) withObject:nil afterDelay:1.0f];
}
- (void)refreshTable{
    _tableView.pullTableIsRefreshing = NO;
    _tableView.pullLastRefreshDate = [NSDate date];
    _page = 1;
    [self loadData];
}
- (void)loadMoreDataToTable{
    _tableView.pullTableIsLoadingMore = NO;
    _page ++;
    [self loadData];
}

#pragma mark 作品
- (void)createNav
{
    self.navigationController.navigationBar.translucent = NO;
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"juchi.png"] forBarMetrics:UIBarMetricsDefault];
    
    self.navigationItem.title = @"作品";
    [self createNavButton];
}

- (void)createNavButton
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
}

- (void)leftButtonClick
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
