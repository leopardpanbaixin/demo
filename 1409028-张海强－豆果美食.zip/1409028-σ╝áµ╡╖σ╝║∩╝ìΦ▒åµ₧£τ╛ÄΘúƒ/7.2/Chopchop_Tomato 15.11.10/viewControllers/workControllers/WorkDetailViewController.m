//
//  WorkDetailViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "WorkDetailViewController.h"
#import "UIImageView+WebCache.h"
#import "UIButton+WebCache.h"
#import "PictureViewController.h"

@interface WorkDetailViewController ()

@end

@implementation WorkDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//        self.view.backgroundColor = [UIColor colorWithRed:224/256.0 green:215/256.0 blue:194/256.0 alpha:1];
    [self createNav];
    [self configUI];
//    [self loadData];
}
#pragma mark 加载数据
- (void)loadData
{
    _request = [[HttpPostRequest alloc] init];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"4",@"client",@"dcab013b33431c7394bdac0a58ea9447",@"sign_ran",@"b3d31ba8e01b3a41",@"code",nil];
    NSString *str = [WORK_DETAIL_URL stringByAppendingString:self.dish_id];
    [_request asiDownloadWithUrlString:str requestMethod:@"POST" paraDic:dic];
    _request.delegate = self;
}
- (void) httpRequestFinished:(HttpPostRequest *)request
{
    
    if (request.downloadData) {
        id result = [NSJSONSerialization JSONObjectWithData:request.downloadData options:NSJSONReadingMutableContainers error:nil];
  
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dataDic = (NSDictionary *)result;
            NSDictionary *dic = [[dataDic objectForKey:@"result"] objectForKey:@"dish"];
            NSLog(@"-----------------%@",dic);
        }
    }
}

- (void) httpRequestFailed:(HttpPostRequest *)request
{
    
}

#pragma mark 布局
- (void)configUI
{
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-[MyControl isIOS7])];
    _scrollView.contentSize = CGSizeMake(ScreenWidth, ScreenHeight+40);
    [self.view addSubview:_scrollView];
    
//    上层大图
    UIImageView *cookImageView = [MyControl createImageViewFrame:CGRectMake(0, 0, ScreenWidth, 300) imageName:nil];
    [cookImageView setImageWithURL:[NSURL URLWithString:self.workModel.image]];
    [_scrollView addSubview:cookImageView];
    
//    添加点击手势
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
    [cookImageView addGestureRecognizer:tap];
//    中部图标
    UIButton *button = [MyControl createButtonWithFrame:CGRectMake(20, cookImageView.bottom+10, 40, 40) target:self SEL:@selector(buttonClick) title:nil imageName:nil bgImageName:nil];
    [button setImageWithURL:[NSURL URLWithString:self.userModel.user_photo]];
    button.layer.cornerRadius = 20;
    button.layer.masksToBounds = YES;
    [_scrollView addSubview:button];
//    中部label
    UILabel *label = [MyControl createLabelWithFrame:CGRectMake(button.right + 10, cookImageView.bottom+10, 100, 40) Font:16 Text:nil];
    label.text = self.userModel.nick;
    label.textColor = [UIColor brownColor];
    [_scrollView addSubview:label];
    
//计算时间
    NSString *dateStr = self.workModel.publishtime;
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    [formater setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *currentDate = [formater dateFromString:dateStr];
    NSDate *date = [NSDate date];
    NSTimeInterval tempTime = [date timeIntervalSinceDate:currentDate];
    
    
     UILabel *label1 = [MyControl createLabelWithFrame:CGRectMake(label.right+60, cookImageView.bottom+10, 160, 40) Font:12 Text:nil];
    label1.textColor = [UIColor grayColor];
    
    int time = (int)(tempTime/60);
    if (time < 1) {
        label1.text = @"刚刚发布";
    } else {
       label1.text = [NSString stringWithFormat:@"%d分钟前发布",time];
    }
    [_scrollView addSubview:label1];
    
//    第三层
    if (self.workModel.ts.count>0) {
        for (int i = 0; i<self.workModel.ts.count; i++) {
            _topicButton = [MyControl createButtonWithFrame:CGRectMake(10+(i%2)*120,label1.bottom + 10 + (i/2)*25, 110, 20) target:self SEL:@selector(topicButtonClick:) title:nil imageName:nil bgImageName:nil];
            NSString *str = [NSString stringWithFormat:@"#%@#",[self.workModel.ts objectAtIndex:i]];
            [_topicButton setTitle:str forState:UIControlStateNormal];
            _topicButton.titleLabel.font = [UIFont systemFontOfSize:12];
            _topicButton.backgroundColor = [UIColor colorWithRed:170/256.0 green:179/256.0 blue:70/256.0 alpha:1];
            _topicButton.layer.cornerRadius = 5;
            _topicButton.layer.masksToBounds = YES;
            _topicButton.tag = 2015+i;
            [_scrollView addSubview:_topicButton];
        }
    }
    
//    第四层
    UILabel *desLabel = [MyControl createLabelWithFrame:CGRectMake(10, label1.bottom+50, 300, 60) Font:16 Text:nil];
    desLabel.text = self.workModel.description;
    desLabel.numberOfLines = 0;
    desLabel.textColor = [UIColor brownColor];
    [_scrollView addSubview:desLabel];
    
//底层
    UIToolbar *bar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 376, 320, 40)];
    bar.backgroundColor = [UIColor redColor];
    [self.view addSubview:bar];
    UIButton *bottomButtom = [MyControl createButtonWithFrame:CGRectMake(5, 0, 310, 40) target:self SEL:@selector(bottomClick) title:nil imageName:nil bgImageName:nil];
    bottomButtom.backgroundColor = [UIColor brownColor];
    [bottomButtom setTitle:@"写评论" forState:UIControlStateNormal];
    [bottomButtom setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [bar addSubview:bottomButtom];
    
}
- (void)bottomClick
{
    
}
- (void)tap
{
    PictureViewController *pic = [[PictureViewController alloc] init];
    pic.photo = self.workModel.image;
    [self presentViewController:pic animated:YES completion:nil];
    [pic release];
}
- (void)topicButtonClick:(UIButton *)button
{
    
}
- (void)buttonClick
{
    
}
#pragma mark 创建导航
- (void)createNav
{
    self.navigationController.navigationBar.translucent = NO;
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"juchi.png"] forBarMetrics:UIBarMetricsDefault];
    
    self.navigationItem.title = self.cook_title;
    [self createNavButton];
}

- (void)createNavButton
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
}

- (void)leftButtonClick
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
