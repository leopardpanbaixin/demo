//
//  WorkDetailViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpPostRequest.h"
#import "WorkModel.h"
#import "UserWorkModel.h"

@interface WorkDetailViewController : UIViewController <HttpRequestDelegate> {
    HttpPostRequest *_request;
    UIScrollView *_scrollView;
    UIButton *_topicButton;
}

@property (nonatomic,copy) NSString *cook_title;
@property (nonatomic,copy) NSString *dish_id;
@property (nonatomic,retain) NSMutableArray *dataArray;
@property (nonatomic,retain) WorkModel *workModel;
@property (nonatomic,retain) UserWorkModel *userModel;

@end
