//
//  PictureViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "PictureViewController.h"
#import "UIImageView+WebCache.h"

@interface PictureViewController ()

@end

@implementation PictureViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
       
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
     self.view.backgroundColor = [UIColor blackColor];
    
    
    UIImageView *imageView = [MyControl createImageViewFrame:CGRectMake(0, 90, ScreenWidth, ScreenHeight-90*2) imageName:nil];
    imageView.backgroundColor = [UIColor clearColor];
    [imageView setImageWithURL:[NSURL URLWithString:self.photo]];

    [self.view addSubview:imageView];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
    [imageView addGestureRecognizer:tap];
    
//    UILongPressGestureRecognizer *_long = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longClick)];
//    [imageView addGestureRecognizer:_long];
}


- (void)longClick
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"保存图片" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"保存", nil];
    [alertView show];
    [alertView release];
}
- (void)tap
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
