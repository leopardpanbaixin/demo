//
//  PictureViewController.h
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-7-2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PictureViewController : UIViewController <UIAlertViewDelegate>

@property (nonatomic,copy) NSString *photo;

@end
