//
//  SettingViewController.m
//  Chopchop_Tomato
//
//  Created by qianfeng on 14-6-27.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "SettingViewController.h"
#import "LocationViewController.h"
#import "AboutUSViewController.h"
#import "UMFeedback.h"

@interface SettingViewController ()

@end

@implementation SettingViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self createNav];
    _LocationLabel.text = self.city;
}

- (void)createNav
{
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"juchi"] forBarMetrics:UIBarMetricsDefault];
    self.navigationItem.title = @"设置";
    [self createNavButton];
}

- (void)createNavButton
{
    //    创建左导航
    UIButton *leftButton = [MyControl createButtonWithFrame:CGRectMake(0, 0, 25, 25) target:self SEL:@selector(leftButtonClick) title:nil imageName:nil bgImageName:nil];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left"]  forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"rec_navbar_left_selected"] forState:UIControlStateSelected];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [leftItem release];
}

- (void)leftButtonClick
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_LocationLabel release];
    [super dealloc];
}
- (IBAction)loginButtonClick:(id)sender {
   
}

- (IBAction)feedbackClick:(id)sender {
    [UMFeedback showFeedback:self withAppkey:@"53858f0456240bc69206f412"];
}

- (IBAction)updateClick:(id)sender {
}

- (IBAction)aboutClick:(id)sender {
    AboutUSViewController *about = [[AboutUSViewController alloc] init];
    [self.navigationController pushViewController:about animated:YES];
    [about release];
}

- (IBAction)soundClick:(id)sender {
}

- (IBAction)pushClick:(id)sender {
}
- (IBAction)locationClick:(id)sender {
    LocationViewController *location = [[LocationViewController alloc] init];
    [self.navigationController pushViewController:location animated:YES];
    [location release];
}
@end
