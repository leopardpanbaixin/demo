//
//  fiveView.m
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "fiveView.h"

@implementation fiveView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self _initView];
    }
    return self;
}

- (void)_initView
{
//    气泡文字
    UIImage *image = [UIImage imageNamed:@"cam_tip_bgimg@2x.png"];
    image = [image  stretchableImageWithLeftCapWidth:12 topCapHeight:6];
    _customImageView = [MyControl createImageViewFrame:CGRectMake(60, 25, ScreenWidth-75, 60) imageName:nil];
    _customImageView.image = image;
    UILabel *label = [MyControl createLabelWithFrame:CGRectMake(1, 15, _customImageView.width-2, 40) Font:16 Text:nil];
    label.text = @"扫下餐后的小票                          我也能写出让人落泪的美文食记了";
    label.textColor = [UIColor whiteColor];
    
    [_customImageView addSubview:label];
    [self addSubview:_customImageView];
    [UIView animateWithDuration:0.2 animations:^{
        _customImageView.transform = CGAffineTransformScale(_customImageView.transform, 1.2, 1.2);
    } completion:^(BOOL finished) {
        _customImageView.transform = CGAffineTransformIdentity;
    }];
    
    _imageView2 = [MyControl createImageViewFrame:CGRectMake(_customImageView.left+55, _customImageView.bottom+35, 135, 250) imageName:@"cmagStepFiveC@2x.png"];
    [self addSubview:_imageView2];
    [UIView animateWithDuration:0.4 animations:^{
        _imageView2.transform = CGAffineTransformMakeScale(1.2, 1.2);
    } completion:^(BOOL finished) {
        _imageView2.transform = CGAffineTransformIdentity;
    }];
    UIImageView *imageView5 = [MyControl createImageViewFrame:CGRectMake(ScreenWidth-90, ScreenHeight-65, 35, 35) imageName:@"cmagNextButton@2x.png"];
    [self addSubview:imageView5];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
