//
//  threeView.m
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "threeView.h"

@implementation threeView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self _initView];
    }
    return self;
}

- (void)_initView
{
    //    气泡文字
    UIImage *image = [UIImage imageNamed:@"cam_tip_bgimg@2x.png"];
    image = [image  stretchableImageWithLeftCapWidth:12 topCapHeight:6];
    _customImageView = [MyControl createImageViewFrame:CGRectMake(135, 25, ScreenWidth-150, 60) imageName:nil];
    _customImageView.image = image;
    UILabel *label = [MyControl createLabelWithFrame:CGRectMake(5, 15, _customImageView.width- 10, 40) Font:16 Text:nil];
    label.text = @"女盆友想吃金鼎轩，  提起用手机查好菜";
    label.textColor = [UIColor whiteColor];
    
    [_customImageView addSubview:label];
    [self addSubview:_customImageView];
    [UIView animateWithDuration:0.2 animations:^{
        _customImageView.transform = CGAffineTransformScale(_customImageView.transform, 1.2, 1.2);
    } completion:^(BOOL finished) {
        _customImageView.transform = CGAffineTransformIdentity;
    }];
    
//    中部布局
    _tempView = [MyControl createImageViewFrame:CGRectMake(100,_customImageView.bottom+100, 120, 140) imageName:@"cmagStepThreeC@2x.png"];
    [self addSubview:_tempView];
    
    _imageView2 = [MyControl createImageViewFrame:CGRectMake(100, 140, 130, 190) imageName:@"cmagStepThreeC@2x.png"];
    [self addSubview:_imageView2];
    
    [UIView animateWithDuration:0.3 animations:^{
        _imageView2.hidden = YES;
        _tempView.transform = CGAffineTransformMakeScale(0.6, 0.6);
    } completion:^(BOOL finished) {
        
        [UIView animateWithDuration:0.4 animations:^{
            _imageView2.hidden = NO;
            _imageView2.transform = CGAffineTransformMakeScale(0.7, 0.7);
        } completion:^(BOOL finished) {
            _tempView.hidden = YES;
            _imageView2.transform = CGAffineTransformIdentity;
        }];
       
    }];


    _imageView3 = [MyControl createImageViewFrame:CGRectMake(60, _imageView2.bottom - 50, 200, 100) imageName:@"cmagDishBill@2x.png"];
    [self addSubview:_imageView3];
// 底部第一个动画
    UIImageView *imageView1 = [MyControl createImageViewFrame:CGRectMake(50, _imageView2.bottom-37, 45, 25) imageName:@"cmagStepThreeRestOne@2x.png"];
    imageView1.hidden = YES;
    UIImageView *imageView2 = [MyControl createImageViewFrame:CGRectMake(imageView1.left-10, imageView1.bottom-2, 75, 35) imageName:@"cmagDishBill@2x.png"];
    [self addSubview:imageView1];
    [self addSubview:imageView2];
    
    [UIView animateWithDuration:0.3 animations:^{
        _imageView3.frame = CGRectMake(45, imageView1.bottom-10, 0, 0);
    } completion:^(BOOL finished) {
        imageView1.hidden = NO;
    }];
    UIImageView *imageView5 = [MyControl createImageViewFrame:CGRectMake(ScreenWidth-90, ScreenHeight-65, 35, 35) imageName:@"cmagNextButton@2x.png"];
    [self addSubview:imageView5];
//底部第二个动画
    UIImageView *imageView3 = [MyControl createImageViewFrame:CGRectMake(50, _imageView2.bottom-37, 45, 25) imageName:@"cmagStepThreeRestThree@2x.png"];
    [self addSubview:imageView3];
    UIImageView *imageView4 = [MyControl createImageViewFrame:CGRectMake(imageView1.left-10, imageView1.bottom-2, 75, 35) imageName:@"cmagDishBill@2x.png"];
    [self addSubview:imageView4];
    imageView3.hidden = YES;
    [UIView animateWithDuration:0.4 animations:^{
        imageView3.hidden = NO;
        imageView3.transform = CGAffineTransformMakeTranslation(imageView1.right, 0);
        imageView4.transform = CGAffineTransformMakeTranslation(imageView2.right-25, 0);
    }];
    
//   底部第三个动画
    UIImageView *imageView6 = [MyControl createImageViewFrame:CGRectMake(50, _imageView2.bottom-37, 45, 25)  imageName:@"cmagStepThreeRestThree@2x.png"];
    [self addSubview:imageView6];
    UIImageView *imageView7 = [MyControl createImageViewFrame:CGRectMake(imageView1.left-10, imageView1.bottom-2, 75, 35) imageName:@"cmagDishBill@2x.png"];
    [self addSubview:imageView7];
    imageView6.hidden = YES;
    [UIView animateWithDuration:0.5 animations:^{
        imageView6.hidden = NO;
        imageView6.transform = CGAffineTransformMakeTranslation(imageView3.right, 0);
        imageView7.transform = CGAffineTransformMakeTranslation(imageView4.right-25, 0);
    }];
}

- (void)makeAnimation
{
    //    中部动画
    [UIView animateWithDuration:0.5 animations:^{
        _imageView2.hidden = YES;
        
        _tempView.transform = CGAffineTransformScale(_tempView.transform, 0.3, 0.3);
        
        
    } completion:^(BOOL finished) {
        _tempView.transform = CGAffineTransformIdentity;
        _imageView2.hidden = NO;
        [UIView animateWithDuration:0.1 animations:^{
            _imageView2.transform = CGAffineTransformTranslate(_imageView2.transform, 0.6, 0.6);
            
        } completion:^(BOOL finished) {
            _imageView3.hidden = NO;
            _imageView2.transform = CGAffineTransformIdentity;
            [UIView animateWithDuration:0.1 animations:^{
                _imageView3.transform = CGAffineTransformScale(_imageView3.transform, 0.7, 0.7);
            } completion:^(BOOL finished) {
                _imageView3.transform = CGAffineTransformIdentity;
                
            }];
        }];
        
        
    }];
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
