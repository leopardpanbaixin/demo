//
//  sixView.m
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "sixView.h"
#import "RootViewController.h"

@implementation sixView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self _initView];
    }
    return self;
}
- (void)_initView
{
    //    气泡文字
    UIImage *image = [UIImage imageNamed:@"cam_tip_bgimg@2x.png"];
    image = [image  stretchableImageWithLeftCapWidth:12 topCapHeight:6];
    _customImageView = [MyControl createImageViewFrame:CGRectMake(125, 25, ScreenWidth-140, 60) imageName:nil];
    _customImageView.image = image;
    UILabel *label = [MyControl createLabelWithFrame:CGRectMake(2, 15, _customImageView.width, 40) Font:16 Text:nil];
    label.text = @"“他”就是我，蕃茄快点   你的美食之旅有我相伴～";
    label.textColor = [UIColor whiteColor];
    
    [_customImageView addSubview:label];
    [self addSubview:_customImageView];
    
    
    [UIView animateWithDuration:0.2 animations:^{
        _customImageView.transform = CGAffineTransformScale(_customImageView.transform, 1.2, 1.2);
    } completion:^(BOOL finished) {
        _customImageView.transform = CGAffineTransformIdentity;
    }];
    
    //界面中的图形布局
    _imageView3 = [MyControl createImageViewFrame:CGRectMake(80, 290, 150, 60) imageName:@"cmagDishBill@2x.png"];
    [self addSubview:_imageView3];
    UIImageView *imageView1 = [MyControl createImageViewFrame:CGRectMake(100,_imageView3.top-130, 120, 140) imageName:@"cmagSmallIcon_Two@2x.png"];
    [self addSubview:imageView1];
    [UIView animateWithDuration:0.3 animations:^{
        imageView1.transform = CGAffineTransformScale(imageView1.transform, 1.2, 1.2);
    } completion:^(BOOL finished) {
        imageView1.transform = CGAffineTransformIdentity;
    }];
    
    
    
    //    底部布局
   
//    UIImageView *imageView5 = [MyControl createImageViewFrame:CGRectMake(40, ScreenHeight-65, 240, 45) imageName:@"cmagLockBg@2x.png"];
//    [self addSubview:imageView5];
//    
//    UIImageView *imageView4 = [MyControl createImageViewFrame:CGRectMake(55, ScreenHeight-62, 38, 35) imageName:@"cmagTeaCup@2x.png"];
//    [self addSubview:imageView4];
    
    [self loadView];
}

- (void)loadView {
	// Load the track background
	UIImage *trackImage = [UIImage imageNamed:@"cmagLockBg"];
	sliderBackground = [[UIImageView alloc] initWithImage:trackImage];
    sliderBackground.frame = CGRectMake(40, ScreenHeight-65, 240, 45);
    sliderBackground.userInteractionEnabled = YES;
	
	// Create the superview same size as track backround, and add the background image to it
//	self.frame = sliderBackground.frame;
	[self addSubview:sliderBackground];
	
	// Add the slider with correct geometry centered over the track
	slider = [[UISlider alloc] initWithFrame:CGRectMake(10, 0, 240, 45)];
//	CGRect sliderFrame = slider.frame;
//	sliderFrame.size.width -= 46; //each "edge" of the track is 23 pixels wide
//	slider.frame = sliderFrame;
//	slider.center = sliderBackground.center;
	slider.backgroundColor = [UIColor clearColor];
	[slider setMinimumTrackImage:[UIImage imageNamed:@"sliderMaxMin-02.png"] forState:UIControlStateNormal];
	[slider setMaximumTrackImage:[UIImage imageNamed:@"sliderMaxMin-02.png"] forState:UIControlStateNormal];
	UIImage *thumbImage = [UIImage imageNamed:@"cmagTeaCup"];
	[slider setThumbImage:thumbImage forState:UIControlStateNormal];
	slider.minimumValue = 0.0;
	slider.maximumValue = 1.0;
	slider.continuous = YES;
	slider.value = 0.0;
	
	[slider addTarget:self
			   action:@selector(sliderChanged:)
	 forControlEvents:UIControlEventValueChanged];
    
	[sliderBackground addSubview:slider];
}

- (void) sliderChanged: (UISlider *) sender
{
	if (slider.value >= 0.2) {
        [slider setValue:1 animated:YES];
        
        RootViewController *root = [[RootViewController alloc]init];
        UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:root];
        [[UIApplication sharedApplication].delegate window].rootViewController = nc;
	}
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
