//
//  fourView.m
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "fourView.h"

@implementation fourView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self _initView];
    }
    return self;
}

- (void)_initView
{
//    气泡文字
        UIImage *image = [UIImage imageNamed:@"cam_tip_bgimg@2x.png"];
        image = [image  stretchableImageWithLeftCapWidth:12 topCapHeight:6];
        _customImageView = [MyControl createImageViewFrame:CGRectMake(135, 25, ScreenWidth-150, 60) imageName:nil];
        _customImageView.image = image;
        UILabel *label = [MyControl createLabelWithFrame:CGRectMake(5, 15, _customImageView.width- 10, 40) Font:16 Text:nil];
        label.text = @"来到陌生的地方           有啥好吃的，一目了然";
        label.textColor = [UIColor whiteColor];
        
        [_customImageView addSubview:label];
        [self addSubview:_customImageView];
        [UIView animateWithDuration:0.2 animations:^{
            _customImageView.transform = CGAffineTransformScale(_customImageView.transform, 1.2, 1.2);
        } completion:^(BOOL finished) {
            _customImageView.transform = CGAffineTransformIdentity;
        }];
        
//中部动画
    _imageView2 = [MyControl createImageViewFrame:CGRectMake(50,_customImageView.bottom+50, 220, 240) imageName:@"cmagStepFourC@2x.png"];
    [self addSubview:_imageView2];
    [UIView animateWithDuration:0.4 animations:^{
        _imageView2.transform = CGAffineTransformMakeScale(1.2, 1.2);
    } completion:^(BOOL finished) {
        _imageView2.transform = CGAffineTransformIdentity;
    }];
    
// 底部第一个动画
    UIImageView *imageView1 = [MyControl createImageViewFrame:CGRectMake(_imageView2.right-75, _imageView2.bottom-60, 70, 25) imageName:@"cmagStepThreeDishOne@2x.png"];
    imageView1.hidden = YES;
    UIImageView *imageView2 = [MyControl createImageViewFrame:CGRectMake(imageView1.left-10, imageView1.bottom-2, 90, 35) imageName:@"cmagDishBill@2x.png"];
    [self addSubview:imageView1];
    [self addSubview:imageView2];
    
    [UIView animateWithDuration:0.5 animations:^{
        imageView1.hidden = NO;
        imageView1.transform = CGAffineTransformTranslate(imageView1.transform, -150, -150);
        imageView2.transform = CGAffineTransformTranslate(imageView1.transform, 0, 0);
    }];
    UIImageView *imageView5 = [MyControl createImageViewFrame:CGRectMake(ScreenWidth-90, ScreenHeight-65, 35, 35) imageName:@"cmagNextButton@2x.png"];
    [self addSubview:imageView5];
    
//    底部第二个动画
    UIImageView *imageView3 = [MyControl createImageViewFrame:CGRectMake(_imageView2.right-75, _imageView2.bottom-60, 70, 25) imageName:@"cmagStepThreeDishThree@2x.png"];
    imageView3.hidden = YES;
    UIImageView *imageView4 = [MyControl createImageViewFrame:CGRectMake(imageView3.left-10, imageView3.bottom-2, 90, 35) imageName:@"cmagDishBill@2x.png"];
    [self addSubview:imageView3];
    [self addSubview:imageView4];
    
    [UIView animateWithDuration:0.5 animations:^{
        imageView3.hidden = NO;
        imageView3.transform = CGAffineTransformTranslate(imageView3.transform, -140, -60);
        imageView4.transform = CGAffineTransformTranslate(imageView3.transform, 0, 0);
    }];

//底部第三个动画
    UIImageView *imageView6 = [MyControl createImageViewFrame:CGRectMake(_imageView2.right-75, _imageView2.bottom-60, 70, 25) imageName:@"cmagStepThreeDishTwo@2x.png"];
    imageView6.hidden = YES;
    UIImageView *imageView7 = [MyControl createImageViewFrame:CGRectMake(imageView6.left-10, imageView6.bottom-2, 90, 35) imageName:@"cmagDishBill@2x.png"];
    [self addSubview:imageView6];
    [self addSubview:imageView7];
    
    [UIView animateWithDuration:0.5 animations:^{
        imageView6.hidden = NO;
        imageView6.transform = CGAffineTransformTranslate(imageView6.transform, -40, -125);
        imageView7.transform = CGAffineTransformTranslate(imageView6.transform, 0, 0);
    }];

}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
