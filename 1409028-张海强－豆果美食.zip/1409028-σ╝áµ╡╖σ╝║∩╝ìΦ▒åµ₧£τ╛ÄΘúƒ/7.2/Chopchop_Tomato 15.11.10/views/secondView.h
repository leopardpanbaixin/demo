//
//  secondView.h
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface secondView : UIView
{
    //    页面上部
    UIImageView *_customImageView;
    //    页面中部
    UIImageView *_imageView2;
    UIImageView *_imageView3;
    
    UIImageView *_tempView;
}
@end
