//
//  secondView.m
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "secondView.h"

@implementation secondView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
         self.backgroundColor = [UIColor colorWithRed:192 green:186 blue:170 alpha:1];
        [self _initView];
    }
    return self;
}

- (void)_initView
{

    //    气泡文字
    UIImage *image = [UIImage imageNamed:@"cam_tip_bgimg@2x.png"];
    image = [image  stretchableImageWithLeftCapWidth:12 topCapHeight:6];
    _customImageView = [MyControl createImageViewFrame:CGRectMake(135, 25, ScreenWidth-150, 60) imageName:nil];
    _customImageView.image = image;
    UILabel *label = [MyControl createLabelWithFrame:CGRectMake(5, 15, _customImageView.width- 10, 40) Font:16 Text:nil];
    label.text = @"到底该不该点红烧肉？哇，扫过才知道热量这么高";
    label.textColor = [UIColor whiteColor];
    
    [_customImageView addSubview:label];
    [self addSubview:_customImageView];
    
    [UIView animateWithDuration:0.2 animations:^{
        _customImageView.transform = CGAffineTransformScale(_customImageView.transform, 1.2, 1.2);
    } completion:^(BOOL finished) {
        _customImageView.transform = CGAffineTransformIdentity;
    }];
    
    //界面中的图形布局
    
    _tempView = [MyControl createImageViewFrame:CGRectMake(100,_customImageView.bottom+100, 120, 140) imageName:@"cmagSmallIcon_one@2x.png"];
    [self addSubview:_tempView];
    
    _imageView2 = [MyControl createImageViewFrame:CGRectMake(100, 140, 130, 190) imageName:@"cmagStepTwoC@2x.png"];
    [self addSubview:_imageView2];
    _imageView3 = [MyControl createImageViewFrame:CGRectMake(60, _imageView2.bottom - 50, 200, 100) imageName:@"cmagDishBill@2x.png"];
    [self addSubview:_imageView3];
    UIImageView *exterImageView = [MyControl createImageViewFrame:CGRectMake(_imageView2.left+22, _imageView2.top+70, 85, 95) imageName:@"cmagStepTwoShadow@2x.png"];
    [self addSubview:exterImageView];
    UIImageView *imageView5 = [MyControl createImageViewFrame:CGRectMake(ScreenWidth-90, ScreenHeight-65, 35, 35) imageName:@"cmagNextButton@2x.png"];
    [self addSubview:imageView5];
    [self makeAnimation];
}

- (void)makeAnimation
{
    //    中部动画
    [UIView animateWithDuration:0.5 animations:^{
        _imageView2.hidden = YES;
        
        _tempView.transform = CGAffineTransformScale(_tempView.transform, 0.3, 0.3);
        
        
    } completion:^(BOOL finished) {
        _tempView.transform = CGAffineTransformIdentity;
        _imageView2.hidden = NO;
        [UIView animateWithDuration:0.1 animations:^{
            _imageView2.transform = CGAffineTransformTranslate(_imageView2.transform, 0.6, 0.6);
            
        } completion:^(BOOL finished) {
            _imageView3.hidden = NO;
            _imageView2.transform = CGAffineTransformIdentity;
            [UIView animateWithDuration:0.1 animations:^{
                _imageView3.transform = CGAffineTransformScale(_imageView3.transform, 0.7, 0.7);
            } completion:^(BOOL finished) {
                _imageView3.transform = CGAffineTransformIdentity;
                
            }];
        }];
        
        
    }];

}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
