//
//  firstView.m
//  Chopchop_Tomato
//
//  Created by JiangLan on 14-6-24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "firstView.h"

@implementation firstView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self _initView];
    }
    return self;
}

- (void)_initView
{
    //    气泡文字
    UIImage *image = [UIImage imageNamed:@"cam_tip_bgimg@2x.png"];
    image = [image  stretchableImageWithLeftCapWidth:12 topCapHeight:6];
    _customImageView = [MyControl createImageViewFrame:CGRectMake(25, 25, ScreenWidth-30, 60) imageName:nil];
    _customImageView.image = image;
    UILabel *label = [MyControl createLabelWithFrame:CGRectMake(2, 15, _customImageView.width, 40) Font:16 Text:nil];
    label.text = @"你好，我是小番，曾经是个“点菜困难户” 直到有一天，我遇到了“他”";
    label.textColor = [UIColor whiteColor];
    [_customImageView addSubview:label];
    [self addSubview:_customImageView];
    
    
    [UIView animateWithDuration:0.2 animations:^{
        _customImageView.transform = CGAffineTransformScale(_customImageView.transform, 1.2, 1.2);
    } completion:^(BOOL finished) {
        _customImageView.transform = CGAffineTransformIdentity;
    }];
    
    //界面中的图形布局
    _imageView3 = [MyControl createImageViewFrame:CGRectMake(80, 290, 150, 60) imageName:@"cmagDishBill@2x.png"];
    [self addSubview:_imageView3];
    UIImageView *imageView1 = [MyControl createImageViewFrame:CGRectMake(100,_imageView3.top-130, 120, 140) imageName:@"cmagSmallIcon_one@2x.png"];
    [self addSubview:imageView1];
    
    //    底部布局
    UIImageView *imageView4 = [MyControl createImageViewFrame:CGRectMake(40, ScreenHeight-65, 40, 40) imageName:@"cmagTeaCup@2x.png"];
    [self addSubview:imageView4];
    UIImageView *imageView5 = [MyControl createImageViewFrame:CGRectMake(ScreenWidth-90, ScreenHeight-65, 35, 35) imageName:@"cmagNextButton@2x.png"];
    [self addSubview:imageView5];
}


@end
