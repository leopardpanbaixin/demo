//
//  MyControl.h
//  QFSnsDemo_1409
//
//  Created by ZhangCheng on 14-5-5.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyControl : NSObject
//使用+方法进行创建 是工厂模式中的一种
//工厂模式：传入参数，出来控件
#pragma mark 创建View
+(UIView*)createViewWithFrame:(CGRect)frame;
#pragma mark 创建label
+(UILabel*)createLabelWithFrame:(CGRect)frame Font:(float)font Text:(NSString*)text;
#pragma mark 创建button
+(UIButton*)createButtonWithFrame:(CGRect)frame target:(id)target SEL:(SEL)method title:(NSString*)title imageName:(NSString*)imageName bgImageName:(NSString*)bgImageName;
#pragma mark 创建imageView
+(UIImageView*)createImageViewFrame:(CGRect)frame imageName:(NSString*)imageName;
#pragma mark 创建textField
+(UITextField*)createTextFieldFrame:(CGRect)frame Font:(float)font textColor:(UIColor*)color leftImageName:(NSString*)leftImageName rightImageName:(NSString*)rightImageName bgImageName:(NSString*)bgImageName placeHolder:(NSString*)placeHolder sucureTextEntry:(BOOL)isOpen;
#pragma mark 判断IOS7下导航高度
+(float)isIOS7;
@end
